import asyncio
import logging
import os
import signal
import sys
import time
import threading
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import schedule
import yaml
from flask import Flask, render_template, jsonify, request

# Import bot modules
from bot.analyzer import AdvancedTechnicalAnalyzer
from bot.chart_generator import ChartGenerator
from bot.signal_tracker import SignalTracker
from bot.telegram_handler import TelegramHandler
from bot.database import DatabaseManager
from bot.utils import setup_logging, load_config, validate_config

# Global variables
analyzer = None
chart_generator = None
signal_tracker = None
telegram_handler = None
db_manager = None
config = None
logger = None
running = True

# Flask application
app = Flask(__name__)

def signal_handler(signum, frame):
    """Handle graceful shutdown"""
    global running
    logger.info("🛑 Received shutdown signal, stopping bot...")
    running = False
    
    # Close database connections
    if db_manager:
        db_manager.close()
    
    sys.exit(0)

def initialize_components():
    """Initialize all bot components"""
    global analyzer, chart_generator, signal_tracker, telegram_handler, db_manager, config, logger
    
    try:
        # Load configuration
        config = load_config()
        validate_config(config)
        
        # Setup logging
        logger = setup_logging(config.get('logging', {}))
        logger.info("🚀 Starting Advanced Trading Bot...")
        
        # Initialize database
        db_manager = DatabaseManager(config.get('database', {}).get('path', 'trading_bot.db'))
        
        # Initialize components
        analyzer = AdvancedTechnicalAnalyzer(config.get('analysis', {}))
        chart_generator = ChartGenerator(config.get('charts', {}))
        signal_tracker = SignalTracker(db_manager, config.get('tracking', {}))
        telegram_handler = TelegramHandler(config.get('telegram', {}))
        
        logger.info("✅ All components initialized successfully")
        return True
        
    except Exception as e:
        if logger:
            logger.error(f"❌ Failed to initialize components: {e}")
        else:
            print(f"❌ Failed to initialize components: {e}")
        return False

def analyze_symbol_timeframe(symbol, timeframe):
    """Analyze a single symbol-timeframe combination"""
    try:
        # Check if we should analyze this combination
        if not should_analyze(symbol, timeframe):
            return None
            
        logger.info(f"🔍 Analyzing {symbol} - {timeframe}")
        
        # Download and analyze data
        analysis_result = analyzer.analyze_symbol(symbol, timeframe)
        if not analysis_result:
            return None
            
        # Generate signal if conditions are met
        signal_data = analyzer.generate_signal(analysis_result, symbol, timeframe)
        if not signal_data or signal_data['type'] == 'HOLD':
            logger.info(f"💤 No actionable signal for {symbol} - {timeframe}")
            return None
            
        # Check if we should send this signal
        if not signal_tracker.should_send_signal(symbol, timeframe, signal_data['type']):
            logger.info(f"⏭️ Signal recently sent for {symbol} - {timeframe}, skipping")
            return None
            
        # Generate chart
        chart_path = chart_generator.create_advanced_chart(
            analysis_result['data'], 
            analysis_result, 
            signal_data, 
            symbol, 
            timeframe
        )
        
        # Prepare signal for sending
        signal_record = signal_tracker.create_signal_record(
            symbol, timeframe, signal_data, chart_path
        )
        
        return signal_record
        
    except Exception as e:
        logger.error(f"❌ Error analyzing {symbol} - {timeframe}: {e}")
        return None

def should_analyze(symbol, timeframe):
    """Check if we should analyze this symbol-timeframe combination"""
    # Check market hours for stock symbols
    if symbol in config['symbols']['stocks']:
        now = datetime.now()
        # Skip if outside market hours (simple check)
        if now.weekday() >= 5:  # Weekend
            return False
            
    # Check if enough time has passed since last analysis
    last_analysis = signal_tracker.get_last_analysis_time(symbol, timeframe)
    if last_analysis:
        time_diff = datetime.now() - last_analysis
        min_interval = config['analysis']['min_intervals'].get(timeframe, 300)  # 5 minutes default
        if time_diff.total_seconds() < min_interval:
            return False
            
    return True

def process_signals_batch():
    """Process multiple signals in parallel"""
    try:
        symbols_to_analyze = []
        
        # Collect all symbol-timeframe combinations to analyze
        for category, symbols in config['symbols'].items():
            for symbol in symbols:
                for timeframe in config['analysis']['timeframes']:
                    symbols_to_analyze.append((symbol, timeframe))
        
        # Process in parallel batches
        batch_size = config['analysis'].get('batch_size', 5)
        with ThreadPoolExecutor(max_workers=batch_size) as executor:
            # Submit analysis tasks
            future_to_symbol = {
                executor.submit(analyze_symbol_timeframe, symbol, timeframe): (symbol, timeframe)
                for symbol, timeframe in symbols_to_analyze
            }
            
            signals_to_send = []
            
            # Collect results
            for future in future_to_symbol:
                try:
                    result = future.result(timeout=60)  # 60 second timeout
                    if result:
                        signals_to_send.append(result)
                except Exception as e:
                    symbol, timeframe = future_to_symbol[future]
                    logger.error(f"❌ Error processing {symbol} - {timeframe}: {e}")
        
        # Send collected signals
        if signals_to_send:
            logger.info(f"📤 Sending {len(signals_to_send)} signals")
            for signal_record in signals_to_send:
                telegram_handler.send_signal(signal_record)
                signal_tracker.save_signal(signal_record)
                time.sleep(1)  # Rate limiting
        
    except Exception as e:
        logger.error(f"❌ Error in batch processing: {e}")

def update_signal_statuses():
    """Update the status of open signals"""
    try:
        open_signals = signal_tracker.get_open_signals()
        updated_count = 0
        
        for signal in open_signals:
            try:
                # Get current price
                current_data = analyzer.get_current_price(signal['symbol'])
                if not current_data:
                    continue
                    
                current_price = current_data['price']
                
                # Check if signal targets are hit
                status_update = signal_tracker.check_signal_status(signal, current_price)
                
                if status_update['status'] != 'OPEN':
                    # Signal closed, send update
                    telegram_handler.send_signal_update(signal, status_update)
                    updated_count += 1
                    
            except Exception as e:
                logger.error(f"❌ Error updating signal {signal['id']}: {e}")
        
        if updated_count > 0:
            logger.info(f"📊 Updated {updated_count} signal statuses")
            
    except Exception as e:
        logger.error(f"❌ Error updating signal statuses: {e}")

def send_performance_report():
    """Send daily performance report"""
    try:
        report = signal_tracker.generate_performance_report()
        if report:
            telegram_handler.send_performance_report(report)
            logger.info("📈 Performance report sent")
    except Exception as e:
        logger.error(f"❌ Error sending performance report: {e}")

def cleanup_old_data():
    """Clean up old data and charts"""
    try:
        # Clean old charts
        chart_generator.cleanup_old_charts()
        
        # Clean old signal data (keep last 90 days)
        signal_tracker.cleanup_old_signals(days=90)
        
        logger.info("🧹 Cleanup completed")
    except Exception as e:
        logger.error(f"❌ Error during cleanup: {e}")

def schedule_tasks():
    """Schedule recurring tasks"""
    try:
        # Main analysis schedule
        for timeframe, interval in config['schedule']['analysis'].items():
            schedule.every(interval).minutes.do(process_signals_batch)
        
        # Signal status updates
        schedule.every(config['schedule']['signal_updates']).minutes.do(update_signal_statuses)
        
        # Performance reports
        schedule.every().day.at("08:00").do(send_performance_report)
        
        # Cleanup
        schedule.every().day.at("02:00").do(cleanup_old_data)
        
        logger.info("⏰ Tasks scheduled successfully")
        
    except Exception as e:
        logger.error(f"❌ Error scheduling tasks: {e}")

def run_scheduler():
    """Run the main scheduler loop"""
    global running
    
    while running:
        try:
            schedule.run_pending()
            time.sleep(10)  # Check every 10 seconds
        except Exception as e:
            logger.error(f"❌ Scheduler error: {e}")
            time.sleep(60)  # Wait longer on error

# Flask Routes
@app.route('/')
def dashboard():
    """Main dashboard route"""
    return render_template('dashboard.html')

@app.route('/api/signals')
def api_signals():
    """API endpoint for signals data"""
    try:
        if db_manager:
            signals = db_manager.get_open_signals()
            return jsonify({'success': True, 'data': signals})
        return jsonify({'success': False, 'error': 'Database not available'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/performance')
def api_performance():
    """API endpoint for performance data"""
    try:
        if signal_tracker:
            days = request.args.get('days', 30, type=int)
            report = signal_tracker.generate_performance_report(days)
            return jsonify({'success': True, 'data': report})
        return jsonify({'success': False, 'error': 'Signal tracker not available'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/status')
def api_status():
    """API endpoint for system status"""
    return jsonify({
        'success': True,
        'data': {
            'status': 'online' if running else 'offline',
            'components': {
                'analyzer': analyzer is not None,
                'telegram': telegram_handler is not None,
                'database': db_manager is not None
            }
        }
    })

@app.route('/api/overview')
def api_overview():
    """API endpoint for overview data"""
    try:
        if signal_tracker and db_manager:
            # Get performance stats
            report = signal_tracker.generate_performance_report(30)
            if report:
                return jsonify({
                    'success': True,
                    'data': {
                        'stats': report.get('summary', {}),
                        'performance_history': []
                    }
                })
        
        return jsonify({
            'success': True,
            'data': {
                'stats': {
                    'total_signals': 0,
                    'win_rate': 0,
                    'total_pnl': 0,
                    'open_signals': 0
                },
                'performance_history': []
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/signals/recent')
def api_signals_recent():
    """API endpoint for recent signals"""
    try:
        if db_manager:
            # Get recent signals from database
            query = """
                SELECT * FROM signals 
                ORDER BY created_at DESC 
                LIMIT 10
            """
            signals = db_manager.fetch_query(query) or []
            return jsonify({'success': True, 'signals': signals})
        
        return jsonify({'success': True, 'signals': []})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/signals/active')
def api_signals_active():
    """API endpoint for active signals"""
    try:
        if db_manager:
            signals = db_manager.get_open_signals()
            
            # Calculate distribution
            distribution = {}
            for signal in signals:
                signal_type = signal.get('signal_type', 'UNKNOWN')
                distribution[signal_type] = distribution.get(signal_type, 0) + 1
            
            return jsonify({
                'success': True,
                'signals': signals,
                'distribution': distribution,
                'top_assets': []
            })
        
        return jsonify({'success': True, 'signals': [], 'distribution': {}, 'top_assets': []})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/analysis')
def api_analysis():
    """API endpoint for analysis data"""
    try:
        return jsonify({
            'success': True,
            'data': {
                'market_sentiment': 'neutral',
                'volume_analysis': {},
                'technical_indicators': []
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

def run_flask_server():
    """Run Flask server in a separate thread"""
    app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False)

def main():
    """Main function"""
    global running
    
    # Setup signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    try:
        # Initialize components
        if not initialize_components():
            sys.exit(1)
        
        # Start Flask server in background thread
        flask_thread = threading.Thread(target=run_flask_server, daemon=True)
        flask_thread.start()
        logger.info("🌐 Web dashboard started on http://0.0.0.0:5000")
        
        # Send startup message
        if telegram_handler:
            telegram_handler.send_startup_message()
        
        # Schedule tasks
        schedule_tasks()
        
        # Run initial analysis
        logger.info("🔄 Running initial analysis...")
        process_signals_batch()
        
        # Start main loop
        logger.info("🔄 Starting main scheduler loop...")
        run_scheduler()
        
    except KeyboardInterrupt:
        logger.info("🛑 Bot stopped by user")
    except Exception as e:
        logger.error(f"❌ Fatal error: {e}")
        sys.exit(1)
    finally:
        if db_manager:
            db_manager.close()

if __name__ == "__main__":
    main()
