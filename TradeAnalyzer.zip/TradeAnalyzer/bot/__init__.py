"""
Advanced Trading Bot Package
"""

__version__ = "2.0.0"
__author__ = "Trading Bot Team"
__description__ = "Advanced Professional Trading Bot with ML Predictions and Signal Tracking"

# Package imports
from .analyzer import AdvancedTechnicalAnalyzer
from .chart_generator import ChartGenerator
from .signal_tracker import SignalTracker
from .telegram_handler import TelegramHandler
from .database import DatabaseManager
from .strategies import TradingStrategies
from .utils import setup_logging, load_config

__all__ = [
    "AdvancedTechnicalAnalyzer",
    "ChartGenerator", 
    "SignalTracker",
    "TelegramHandler",
    "DatabaseManager",
    "TradingStrategies",
    "setup_logging",
    "load_config"
]
