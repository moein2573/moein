import logging
import os
import yaml
import json
import time
import functools
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable
import requests
from pathlib import Path

# Try to import news API
try:
    from newsapi import NewsApiClient
    NEWS_API_AVAILABLE = True
except ImportError:
    NEWS_API_AVAILABLE = False

logger = logging.getLogger(__name__)

def setup_logging(config: Dict = None) -> logging.Logger:
    """Setup comprehensive logging system"""
    if config is None:
        config = {}
    
    # Create logs directory
    os.makedirs('logs', exist_ok=True)
    
    # Configure logging
    log_level = config.get('level', 'INFO')
    log_file = config.get('file', 'logs/trading_bot.log')
    max_size = config.get('max_size', 10485760)  # 10MB
    backup_count = config.get('backup_count', 5)
    console_colors = config.get('console_colors', True)
    
    # Create logger
    logger = logging.getLogger()
    logger.setLevel(getattr(logging, log_level.upper()))
    
    # Clear existing handlers
    logger.handlers.clear()
    
    # File handler with rotation
    try:
        from logging.handlers import RotatingFileHandler
        file_handler = RotatingFileHandler(
            log_file, 
            maxBytes=max_size, 
            backupCount=backup_count,
            encoding='utf-8'
        )
        file_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(file_formatter)
        logger.addHandler(file_handler)
    except Exception as e:
        print(f"Warning: Could not set up file logging: {e}")
    
    # Console handler with colors
    console_handler = logging.StreamHandler()
    
    if console_colors:
        try:
            from colorlog import ColoredFormatter
            console_formatter = ColoredFormatter(
                '%(log_color)s%(asctime)s - %(levelname)s - %(message)s',
                datefmt='%H:%M:%S',
                log_colors={
                    'DEBUG': 'cyan',
                    'INFO': 'green',
                    'WARNING': 'yellow',
                    'ERROR': 'red',
                    'CRITICAL': 'red,bg_white',
                }
            )
        except ImportError:
            console_formatter = logging.Formatter(
                '%(asctime)s - %(levelname)s - %(message)s',
                datefmt='%H:%M:%S'
            )
    else:
        console_formatter = logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s',
            datefmt='%H:%M:%S'
        )
    
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)
    
    return logger

def load_config(config_path: str = 'config.yaml') -> Dict:
    """Load configuration from YAML file"""
    try:
        if not os.path.exists(config_path):
            logger.error(f"❌ Configuration file not found: {config_path}")
            raise FileNotFoundError(f"Configuration file not found: {config_path}")
        
        with open(config_path, 'r', encoding='utf-8') as file:
            config = yaml.safe_load(file)
        
        # Override with environment variables
        config = _override_with_env_vars(config)
        
        logger.info(f"✅ Configuration loaded from {config_path}")
        return config
        
    except Exception as e:
        logger.error(f"❌ Error loading configuration: {e}")
        raise

def _override_with_env_vars(config: Dict) -> Dict:
    """Override configuration with environment variables"""
    # Telegram configuration
    if 'telegram' in config:
        config['telegram']['token'] = os.getenv('TELEGRAM_TOKEN', config['telegram'].get('token', ''))
        config['telegram']['chat_id'] = os.getenv('TELEGRAM_CHAT_ID', config['telegram'].get('chat_id', ''))
    
    # News API
    if 'news' in config:
        config['news']['api_key'] = os.getenv('NEWS_API_KEY', config['news'].get('api_key', ''))
    
    # Database path
    if 'database' in config:
        config['database']['path'] = os.getenv('DATABASE_PATH', config['database'].get('path', 'trading_bot.db'))
    
    return config

def validate_config(config: Dict) -> bool:
    """Validate configuration parameters"""
    required_sections = ['telegram', 'symbols', 'timeframes', 'analysis']
    
    for section in required_sections:
        if section not in config:
            logger.error(f"❌ Missing required configuration section: {section}")
            return False
    
    # Validate Telegram config
    telegram_config = config['telegram']
    if not telegram_config.get('token') or not telegram_config.get('chat_id'):
        logger.error("❌ Telegram token or chat_id not configured")
        return False
    
    # Validate symbols
    symbols = config['symbols']
    if not any(symbols.values()):
        logger.error("❌ No symbols configured for analysis")
        return False
    
    # Validate timeframes
    timeframes = config['timeframes']
    if not timeframes:
        logger.error("❌ No timeframes configured")
        return False
    
    logger.info("✅ Configuration validation passed")
    return True

def cache_data(timeout: int = 300):
    """Decorator for caching function results"""
    def decorator(func: Callable) -> Callable:
        cache = {}
        
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Create cache key
            key = str(args) + str(sorted(kwargs.items()))
            
            # Check if cached result exists and is not expired
            if key in cache:
                result, timestamp = cache[key]
                if time.time() - timestamp < timeout:
                    return result
            
            # Call function and cache result
            result = func(*args, **kwargs)
            cache[key] = (result, time.time())
            
            # Clean old cache entries (keep last 100)
            if len(cache) > 100:
                oldest_keys = sorted(cache.keys(), key=lambda k: cache[k][1])[:50]
                for old_key in oldest_keys:
                    del cache[old_key]
            
            return result
        return wrapper
    return decorator

def get_news_sentiment(symbol: str, max_articles: int = 10) -> Dict:
    """Get news sentiment for a symbol"""
    try:
        if not NEWS_API_AVAILABLE:
            logger.warning("⚠️ NewsAPI library not available")
            return {'sentiment_score': 0, 'article_count': 0, 'sentiment': 'neutral'}
        
        news_api_key = os.getenv('NEWS_API_KEY')
        if not news_api_key:
            logger.warning("⚠️ News API key not configured")
            return {'sentiment_score': 0, 'article_count': 0, 'sentiment': 'neutral'}
        
        newsapi = NewsApiClient(api_key=news_api_key)
        
        # Create search query
        search_terms = _get_search_terms(symbol)
        if not search_terms:
            return {'sentiment_score': 0, 'article_count': 0, 'sentiment': 'neutral'}
        
        # Search for news
        news_data = newsapi.get_everything(
            q=search_terms,
            language='en',
            sort_by='publishedAt',
            page_size=max_articles,
            from_param=(datetime.now() - timedelta(days=7)).strftime('%Y-%m-%d')
        )
        
        articles = news_data.get('articles', [])
        if not articles:
            return {'sentiment_score': 0, 'article_count': 0, 'sentiment': 'neutral'}
        
        # Analyze sentiment
        sentiment_score = _analyze_sentiment(articles)
        
        # Determine sentiment category
        if sentiment_score > 0.1:
            sentiment = 'positive'
        elif sentiment_score < -0.1:
            sentiment = 'negative'
        else:
            sentiment = 'neutral'
        
        return {
            'sentiment_score': round(sentiment_score, 3),
            'article_count': len(articles),
            'sentiment': sentiment
        }
        
    except Exception as e:
        logger.error(f"❌ Error getting news sentiment: {e}")
        return {'sentiment_score': 0, 'article_count': 0, 'sentiment': 'neutral'}

def _get_search_terms(symbol: str) -> str:
    """Get search terms for news based on symbol"""
    # Map symbols to search terms
    search_mapping = {
        'BTC-USD': 'Bitcoin OR BTC',
        'ETH-USD': 'Ethereum OR ETH',
        'AAPL': 'Apple Inc OR AAPL',
        'GOOGL': 'Google OR Alphabet OR GOOGL',
        'MSFT': 'Microsoft OR MSFT',
        'TSLA': 'Tesla OR TSLA',
        'NVDA': 'NVIDIA OR NVDA',
        'AMZN': 'Amazon OR AMZN',
        'META': 'Meta OR Facebook OR META',
    }
    
    return search_mapping.get(symbol, symbol.replace('-USD', '').replace('=X', '').replace('=F', ''))

def _analyze_sentiment(articles: List[Dict]) -> float:
    """Analyze sentiment of news articles"""
    try:
        positive_words = [
            'gain', 'rise', 'growth', 'bull', 'surge', 'profit', 'upgrade', 
            'beat', 'strong', 'breakthrough', 'rally', 'soar', 'boom', 'expand',
            'bullish', 'optimistic', 'positive', 'increase', 'high', 'up'
        ]
        
        negative_words = [
            'loss', 'fall', 'decline', 'bear', 'drop', 'risk', 'cut', 
            'warn', 'weak', 'crash', 'plunge', 'slump', 'concerns', 'fear',
            'bearish', 'pessimistic', 'negative', 'decrease', 'low', 'down'
        ]
        
        total_sentiment = 0
        total_words = 0
        
        for article in articles:
            title = article.get('title', '').lower()
            description = article.get('description', '').lower()
            content = f"{title} {description}"
            
            positive_count = sum(1 for word in positive_words if word in content)
            negative_count = sum(1 for word in negative_words if word in content)
            
            # Calculate sentiment for this article
            word_count = len(content.split())
            if word_count > 0:
                article_sentiment = (positive_count - negative_count) / word_count
                total_sentiment += article_sentiment
                total_words += word_count
        
        # Return normalized sentiment score
        return total_sentiment / len(articles) if articles else 0
        
    except Exception as e:
        logger.error(f"❌ Error analyzing sentiment: {e}")
        return 0

def format_number(number: float, decimals: int = 2) -> str:
    """Format number with appropriate decimal places"""
    if abs(number) >= 1000000:
        return f"{number/1000000:.1f}M"
    elif abs(number) >= 1000:
        return f"{number/1000:.1f}K"
    else:
        return f"{number:.{decimals}f}"

def calculate_rsi(prices: List[float], period: int = 14) -> Optional[float]:
    """Calculate RSI indicator"""
    try:
        if len(prices) < period + 1:
            return None
        
        gains = []
        losses = []
        
        for i in range(1, len(prices)):
            change = prices[i] - prices[i-1]
            if change > 0:
                gains.append(change)
                losses.append(0)
            else:
                gains.append(0)
                losses.append(abs(change))
        
        if len(gains) < period:
            return None
        
        avg_gain = sum(gains[-period:]) / period
        avg_loss = sum(losses[-period:]) / period
        
        if avg_loss == 0:
            return 100
        
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        
        return round(rsi, 2)
        
    except Exception:
        return None

def calculate_sma(prices: List[float], period: int) -> Optional[float]:
    """Calculate Simple Moving Average"""
    try:
        if len(prices) < period:
            return None
        return sum(prices[-period:]) / period
    except Exception:
        return None

def calculate_ema(prices: List[float], period: int) -> Optional[float]:
    """Calculate Exponential Moving Average"""
    try:
        if len(prices) < period:
            return None
        
        multiplier = 2 / (period + 1)
        ema = prices[0]
        
        for price in prices[1:]:
            ema = (price * multiplier) + (ema * (1 - multiplier))
        
        return ema
    except Exception:
        return None

def validate_timeframe(timeframe: str) -> bool:
    """Validate if timeframe is supported"""
    valid_timeframes = ['1m', '5m', '15m', '30m', '1h', '2h', '4h', '6h', '8h', '12h', '1d', '3d', '1wk', '1mo']
    return timeframe in valid_timeframes

def sanitize_filename(filename: str) -> str:
    """Sanitize filename for safe file operations"""
    invalid_chars = '<>:"/\\|?*'
    for char in invalid_chars:
        filename = filename.replace(char, '_')
    return filename

def get_market_hours(symbol: str) -> Dict:
    """Get market hours for a symbol"""
    try:
        now = datetime.now()
        
        # Crypto markets (24/7)
        if any(crypto in symbol for crypto in ['BTC', 'ETH', 'BNB', 'ADA', 'SOL']):
            return {
                'is_open': True,
                'market_type': 'crypto',
                'next_open': None,
                'next_close': None
            }
        
        # Stock markets (weekdays only)
        if symbol in ['AAPL', 'GOOGL', 'MSFT', 'TSLA', 'NVDA', 'AMZN', 'META']:
            is_weekend = now.weekday() >= 5
            is_market_hours = 9 <= now.hour < 16  # Simplified market hours
            
            return {
                'is_open': not is_weekend and is_market_hours,
                'market_type': 'stock',
                'next_open': _calculate_next_market_open(now) if is_weekend or not is_market_hours else None,
                'next_close': _calculate_next_market_close(now) if not is_weekend and is_market_hours else None
            }
        
        # Forex markets (weekdays only, extended hours)
        if '=' in symbol:
            is_weekend = now.weekday() >= 5
            
            return {
                'is_open': not is_weekend,
                'market_type': 'forex',
                'next_open': _calculate_next_forex_open(now) if is_weekend else None,
                'next_close': _calculate_next_forex_close(now) if not is_weekend else None
            }
        
        # Default to always open
        return {
            'is_open': True,
            'market_type': 'other',
            'next_open': None,
            'next_close': None
        }
        
    except Exception as e:
        logger.error(f"❌ Error getting market hours: {e}")
        return {'is_open': True, 'market_type': 'unknown', 'next_open': None, 'next_close': None}

def _calculate_next_market_open(now: datetime) -> datetime:
    """Calculate next market open time"""
    # Simple implementation - next Monday 9 AM if weekend
    days_until_monday = (7 - now.weekday()) % 7
    if days_until_monday == 0:
        days_until_monday = 7
    
    next_open = now.replace(hour=9, minute=0, second=0, microsecond=0)
    next_open += timedelta(days=days_until_monday)
    return next_open

def _calculate_next_market_close(now: datetime) -> datetime:
    """Calculate next market close time"""
    # Simple implementation - today 4 PM
    next_close = now.replace(hour=16, minute=0, second=0, microsecond=0)
    if next_close <= now:
        next_close += timedelta(days=1)
    return next_close

def _calculate_next_forex_open(now: datetime) -> datetime:
    """Calculate next forex open time"""
    # Simple implementation - next Monday
    days_until_monday = (7 - now.weekday()) % 7
    if days_until_monday == 0:
        days_until_monday = 7
    
    next_open = now.replace(hour=0, minute=0, second=0, microsecond=0)
    next_open += timedelta(days=days_until_monday)
    return next_open

def _calculate_next_forex_close(now: datetime) -> datetime:
    """Calculate next forex close time"""
    # Simple implementation - Friday evening
    days_until_friday = (4 - now.weekday()) % 7
    next_close = now.replace(hour=17, minute=0, second=0, microsecond=0)
    next_close += timedelta(days=days_until_friday)
    return next_close

def retry_on_failure(max_retries: int = 3, delay: float = 1.0):
    """Decorator to retry function on failure"""
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None
            
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    if attempt < max_retries - 1:
                        logger.warning(f"⚠️ Attempt {attempt + 1} failed for {func.__name__}: {e}")
                        time.sleep(delay * (2 ** attempt))  # Exponential backoff
                    else:
                        logger.error(f"❌ All {max_retries} attempts failed for {func.__name__}")
            
            raise last_exception
        return wrapper
    return decorator

def measure_execution_time(func: Callable) -> Callable:
    """Decorator to measure function execution time"""
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()
        try:
            result = func(*args, **kwargs)
            execution_time = (time.time() - start_time) * 1000  # Convert to milliseconds
            logger.debug(f"⏱️ {func.__name__} executed in {execution_time:.2f}ms")
            return result
        except Exception as e:
            execution_time = (time.time() - start_time) * 1000
            logger.error(f"❌ {func.__name__} failed after {execution_time:.2f}ms: {e}")
            raise
    return wrapper

def ensure_directory_exists(directory: str):
    """Ensure directory exists, create if it doesn't"""
    try:
        Path(directory).mkdir(parents=True, exist_ok=True)
    except Exception as e:
        logger.error(f"❌ Error creating directory {directory}: {e}")

def clean_old_files(directory: str, max_age_days: int = 7, pattern: str = "*"):
    """Clean old files from directory"""
    try:
        directory_path = Path(directory)
        if not directory_path.exists():
            return
        
        cutoff_time = datetime.now() - timedelta(days=max_age_days)
        deleted_count = 0
        
        for file_path in directory_path.glob(pattern):
            if file_path.is_file():
                file_time = datetime.fromtimestamp(file_path.stat().st_mtime)
                if file_time < cutoff_time:
                    file_path.unlink()
                    deleted_count += 1
        
        if deleted_count > 0:
            logger.info(f"🧹 Cleaned {deleted_count} old files from {directory}")
            
    except Exception as e:
        logger.error(f"❌ Error cleaning old files: {e}")

def get_system_stats() -> Dict:
    """Get basic system statistics"""
    try:
        import psutil
        
        return {
            'cpu_percent': psutil.cpu_percent(interval=1),
            'memory_percent': psutil.virtual_memory().percent,
            'disk_percent': psutil.disk_usage('/').percent,
            'timestamp': datetime.now().isoformat()
        }
    except ImportError:
        # psutil not available
        return {
            'cpu_percent': 0,
            'memory_percent': 0,
            'disk_percent': 0,
            'timestamp': datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"❌ Error getting system stats: {e}")
        return {
            'cpu_percent': 0,
            'memory_percent': 0,
            'disk_percent': 0,
            'timestamp': datetime.now().isoformat()
        }
