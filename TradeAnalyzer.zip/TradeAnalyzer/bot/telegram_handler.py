import asyncio
import logging
import os
from datetime import datetime
from typing import Dict, List, Optional
import json

logger = logging.getLogger(__name__)

# Telegram bot imports
try:
    from telegram import Bot
    from telegram.constants import ParseMode
    from telegram.error import TelegramError, TimedOut, NetworkError
    TELEGRAM_AVAILABLE = True
except ImportError:
    try:
        from telegram import Bot, ParseMode
        from telegram.error import TelegramError, TimedOut, NetworkError
        TELEGRAM_AVAILABLE = True
    except ImportError:
        TELEGRAM_AVAILABLE = False
        logger.warning("⚠️ Telegram library not available")

class TelegramHandler:
    def __init__(self, config: Dict):
        self.config = config
        self.token = os.getenv('TELEGRAM_TOKEN', config.get('token', ''))
        self.chat_id = os.getenv('TELEGRAM_CHAT_ID', config.get('chat_id', ''))
        
        if not TELEGRAM_AVAILABLE:
            logger.error("❌ Telegram library not available. Install python-telegram-bot")
            self.bot = None
            return
        
        if not self.token or not self.chat_id:
            logger.error("❌ Telegram token or chat ID not provided")
            self.bot = None
            return
        
        try:
            self.bot = Bot(token=self.token)
            logger.info("✅ Telegram handler initialized")
        except Exception as e:
            logger.error(f"❌ Error initializing Telegram bot: {e}")
            self.bot = None

    def _format_signal_message(self, signal: Dict) -> str:
        """Format signal data into a comprehensive Telegram message"""
        try:
            # Load symbol names
            from main import config
            symbol_names = config.get('symbol_names', {})
            
            symbol = signal['symbol']
            symbol_name = symbol_names.get(symbol, symbol)
            signal_type = signal['signal_type']
            timeframe = signal['timeframe']
            
            # Signal emoji
            signal_emoji = "🚀" if signal_type == "BUY" else "📉" if signal_type == "SELL" else "⏸️"
            
            # Format message
            message = f"{signal_emoji} **{signal_type} SIGNAL** {signal_emoji}\n\n"
            message += f"**📊 Asset:** {symbol_name} ({symbol})\n"
            message += f"**⏰ Timeframe:** {timeframe}\n"
            message += f"**💰 Entry Price:** ${signal['entry_price']:.6f}\n\n"
            
            # Risk Management
            message += "**🎯 Risk Management:**\n"
            if signal.get('stop_loss'):
                message += f"🛑 Stop Loss: ${signal['stop_loss']:.6f}\n"
            if signal.get('take_profit'):
                message += f"🎯 Take Profit: ${signal['take_profit']:.6f}\n"
            if signal.get('risk_reward'):
                message += f"⚖️ Risk/Reward: {signal['risk_reward']:.2f}\n"
            if signal.get('position_size'):
                message += f"📏 Position Size: {signal['position_size']:.2f}%\n"
            
            message += "\n"
            
            # Signal Strength
            message += "**📈 Signal Analysis:**\n"
            message += f"💪 Strength: {signal.get('strength', 0):.1f}/5\n"
            message += f"🎯 Confidence: {signal.get('confidence', 0):.1f}%\n\n"
            
            # Strategy Breakdown
            if 'strategy_breakdown' in signal:
                try:
                    strategies = json.loads(signal['strategy_breakdown']) if isinstance(signal['strategy_breakdown'], str) else signal['strategy_breakdown']
                    if strategies:
                        message += "**🧠 Strategy Analysis:**\n"
                        for strategy, data in strategies.items():
                            if isinstance(data, dict) and 'score' in data:
                                score = data['score']
                                emoji = "🟢" if score > 0 else "🔴" if score < 0 else "🟡"
                                message += f"{emoji} {strategy.replace('_', ' ').title()}: {score:+.1f}\n"
                        message += "\n"
                except:
                    pass
            
            # Technical Patterns
            if 'patterns' in signal:
                try:
                    patterns = json.loads(signal['patterns']) if isinstance(signal['patterns'], str) else signal['patterns']
                    if patterns:
                        message += "**🕯️ Detected Patterns:**\n"
                        for pattern in patterns[:3]:  # Show max 3 patterns
                            pattern_name = pattern.replace('_', ' ').title()
                            message += f"🔹 {pattern_name}\n"
                        message += "\n"
                except:
                    pass
            
            # Volume Analysis
            if 'volume_analysis' in signal:
                try:
                    volume = json.loads(signal['volume_analysis']) if isinstance(signal['volume_analysis'], str) else signal['volume_analysis']
                    if volume:
                        vol_trend = volume.get('volume_trend', 'normal')
                        vol_emoji = "🔥" if vol_trend == 'high' else "❄️" if vol_trend == 'low' else "🌊"
                        message += f"**📊 Volume:** {vol_emoji} {vol_trend.title()}"
                        
                        if volume.get('volume_ratio'):
                            message += f" ({volume['volume_ratio']:.1f}x avg)"
                        message += "\n\n"
                except:
                    pass
            
            # ML Prediction
            if 'ml_prediction' in signal:
                try:
                    ml_pred = json.loads(signal['ml_prediction']) if isinstance(signal['ml_prediction'], str) else signal['ml_prediction']
                    if ml_pred and ml_pred.get('predicted_change'):
                        direction = ml_pred.get('direction', 'neutral')
                        change = ml_pred.get('predicted_change', 0)
                        ml_confidence = ml_pred.get('confidence', 0)
                        
                        direction_emoji = "🤖📈" if direction == 'bullish' else "🤖📉" if direction == 'bearish' else "🤖➡️"
                        message += f"**{direction_emoji} AI Prediction:**\n"
                        message += f"Direction: {direction.title()} ({change:+.2f}%)\n"
                        message += f"ML Confidence: {ml_confidence:.1f}%\n\n"
                except:
                    pass
            
            # Timestamp
            created_at = signal.get('created_at', datetime.now().isoformat())
            if isinstance(created_at, str):
                try:
                    dt = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
                    formatted_time = dt.strftime('%Y-%m-%d %H:%M:%S UTC')
                except:
                    formatted_time = created_at
            else:
                formatted_time = str(created_at)
            
            message += f"**⏰ Generated:** {formatted_time}\n"
            
            # Disclaimer
            message += "\n⚠️ **Disclaimer:** This is not financial advice. Always do your own research and manage your risk appropriately."
            
            return message
            
        except Exception as e:
            logger.error(f"❌ Error formatting signal message: {e}")
            return f"🚨 Signal Alert: {signal.get('signal_type', 'UNKNOWN')} for {signal.get('symbol', 'UNKNOWN')}"

    def _format_signal_update_message(self, signal: Dict, status_update: Dict) -> str:
        """Format signal status update message"""
        try:
            from main import config
            symbol_names = config.get('symbol_names', {})
            
            symbol = signal['symbol']
            symbol_name = symbol_names.get(symbol, symbol)
            signal_type = signal['signal_type']
            status = status_update['status']
            
            # Status emoji
            if status == 'CLOSED_PROFIT':
                status_emoji = "✅💰"
                status_text = "PROFIT"
            elif status == 'CLOSED_LOSS':
                status_emoji = "❌📉"
                status_text = "LOSS"
            elif status == 'EXPIRED':
                status_emoji = "⏰🔚"
                status_text = "EXPIRED"
            else:
                status_emoji = "ℹ️"
                status_text = status
            
            message = f"{status_emoji} **SIGNAL {status_text}** {status_emoji}\n\n"
            message += f"**📊 Asset:** {symbol_name} ({symbol})\n"
            message += f"**📈 Signal:** {signal_type}\n"
            message += f"**💰 Entry:** ${signal['entry_price']:.6f}\n"
            message += f"**🏁 Exit:** ${status_update['close_price']:.6f}\n\n"
            
            # P&L Information
            pnl_percent = status_update.get('pnl_percent', 0)
            pnl_points = status_update.get('pnl_points', 0)
            
            pnl_emoji = "💰" if pnl_percent > 0 else "💸" if pnl_percent < 0 else "➡️"
            message += f"**{pnl_emoji} Performance:**\n"
            message += f"P&L: {pnl_percent:+.2f}% ({pnl_points:+.6f} points)\n"
            
            if status_update.get('close_reason'):
                message += f"Reason: {status_update['close_reason']}\n"
            
            # Signal duration
            try:
                created_at = datetime.fromisoformat(signal['created_at'].replace('Z', '+00:00'))
                closed_at = datetime.now()
                duration = closed_at - created_at
                hours = duration.total_seconds() / 3600
                message += f"Duration: {hours:.1f} hours\n"
            except:
                pass
            
            message += f"\n⏰ **Closed:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')}"
            
            return message
            
        except Exception as e:
            logger.error(f"❌ Error formatting update message: {e}")
            return f"🔄 Signal Update: {signal.get('symbol', 'UNKNOWN')} - {status_update.get('status', 'UNKNOWN')}"

    def _format_performance_report(self, report: Dict) -> str:
        """Format performance report message"""
        try:
            summary = report['summary']
            
            message = "📊 **PERFORMANCE REPORT** 📊\n\n"
            message += f"**📅 Period:** {report['period']}\n\n"
            
            # Overall Performance
            message += "**📈 Overall Performance:**\n"
            message += f"Total Signals: {summary['total_signals']}\n"
            message += f"✅ Winners: {summary['winning_signals']}\n"
            message += f"❌ Losers: {summary['losing_signals']}\n"
            message += f"🎯 Win Rate: {summary['win_rate']}%\n"
            message += f"💰 Total P&L: {summary['total_pnl']:+.2f}%\n\n"
            
            # Trade Analysis
            message += "**🔍 Trade Analysis:**\n"
            message += f"📈 Avg Win: +{summary['avg_win']:.2f}%\n"
            message += f"📉 Avg Loss: -{summary['avg_loss']:.2f}%\n"
            message += f"⚖️ Profit Factor: {summary['profit_factor']:.2f}\n"
            message += f"📊 Max Drawdown: {summary['max_drawdown']:.2f}%\n\n"
            
            # Best and Worst Trades
            if 'best_trade' in report:
                best = report['best_trade']
                message += f"🏆 **Best Trade:** {best['symbol']} (+{best['pnl']:.2f}%)\n"
            
            if 'worst_trade' in report:
                worst = report['worst_trade']
                message += f"💔 **Worst Trade:** {worst['symbol']} ({worst['pnl']:.2f}%)\n\n"
            
            # Strategy Performance
            if 'strategy_performance' in report and report['strategy_performance']:
                message += "**🧠 Strategy Performance:**\n"
                for strategy, perf in report['strategy_performance'].items():
                    strategy_name = strategy.replace('_', ' ').title()
                    avg_pnl = perf['avg_pnl']
                    emoji = "🟢" if avg_pnl > 0 else "🔴" if avg_pnl < 0 else "🟡"
                    message += f"{emoji} {strategy_name}: {avg_pnl:+.2f}% ({perf['signals']} signals)\n"
            
            message += f"\n⏰ **Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')}"
            
            return message
            
        except Exception as e:
            logger.error(f"❌ Error formatting performance report: {e}")
            return "📊 Performance Report - Error formatting data"

    async def _send_message_async(self, message: str, chart_path: str = None) -> Optional[int]:
        """Send message asynchronously"""
        if not self.bot:
            logger.error("❌ Telegram bot not initialized")
            return None
        
        try:
            # Send photo with caption if chart exists
            if chart_path and os.path.exists(chart_path):
                with open(chart_path, 'rb') as photo:
                    response = await self.bot.send_photo(
                        chat_id=self.chat_id,
                        photo=photo,
                        caption=message,
                        parse_mode=ParseMode.MARKDOWN
                    )
                    return response.message_id
            else:
                # Send text message only
                response = await self.bot.send_message(
                    chat_id=self.chat_id,
                    text=message,
                    parse_mode=ParseMode.MARKDOWN,
                    disable_web_page_preview=True
                )
                return response.message_id
                
        except TelegramError as e:
            if "can't parse entities" in str(e).lower():
                # Fallback to plain text if markdown parsing fails
                try:
                    # Remove markdown formatting
                    plain_message = message.replace('**', '').replace('*', '').replace('`', '')
                    response = await self.bot.send_message(
                        chat_id=self.chat_id,
                        text=plain_message,
                        disable_web_page_preview=True
                    )
                    return response.message_id
                except Exception as fallback_e:
                    logger.error(f"❌ Fallback message send failed: {fallback_e}")
                    return None
            else:
                logger.error(f"❌ Telegram error: {e}")
                return None
        except Exception as e:
            logger.error(f"❌ Error sending message: {e}")
            return None

    def send_signal(self, signal: Dict) -> bool:
        """Send trading signal to Telegram"""
        try:
            if not self.bot:
                logger.warning("⚠️ Telegram bot not available, signal not sent")
                return False
            
            message = self._format_signal_message(signal)
            chart_path = signal.get('chart_path')
            
            # Run async function
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
            try:
                message_id = loop.run_until_complete(
                    self._send_message_async(message, chart_path)
                )
                
                if message_id:
                    logger.info(f"✅ Signal sent to Telegram (ID: {message_id})")
                    return True
                else:
                    logger.error("❌ Failed to send signal to Telegram")
                    return False
                    
            finally:
                loop.close()
                
        except Exception as e:
            logger.error(f"❌ Error sending signal: {e}")
            return False

    def send_signal_update(self, signal: Dict, status_update: Dict) -> bool:
        """Send signal status update to Telegram"""
        try:
            if not self.bot:
                logger.warning("⚠️ Telegram bot not available, update not sent")
                return False
            
            message = self._format_signal_update_message(signal, status_update)
            
            # Run async function
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
            try:
                message_id = loop.run_until_complete(
                    self._send_message_async(message)
                )
                
                if message_id:
                    logger.info(f"✅ Signal update sent to Telegram (ID: {message_id})")
                    return True
                else:
                    logger.error("❌ Failed to send update to Telegram")
                    return False
                    
            finally:
                loop.close()
                
        except Exception as e:
            logger.error(f"❌ Error sending signal update: {e}")
            return False

    def send_performance_report(self, report: Dict) -> bool:
        """Send performance report to Telegram"""
        try:
            if not self.bot:
                logger.warning("⚠️ Telegram bot not available, report not sent")
                return False
            
            message = self._format_performance_report(report)
            
            # Run async function
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
            try:
                message_id = loop.run_until_complete(
                    self._send_message_async(message)
                )
                
                if message_id:
                    logger.info(f"✅ Performance report sent to Telegram (ID: {message_id})")
                    return True
                else:
                    logger.error("❌ Failed to send report to Telegram")
                    return False
                    
            finally:
                loop.close()
                
        except Exception as e:
            logger.error(f"❌ Error sending performance report: {e}")
            return False

    def send_startup_message(self) -> bool:
        """Send bot startup notification"""
        try:
            if not self.bot:
                return False
            
            message = "🤖 **TRADING BOT STARTED** 🤖\n\n"
            message += f"✅ Bot initialized successfully\n"
            message += f"⏰ Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')}\n"
            message += f"🔍 Monitoring markets for trading opportunities...\n\n"
            message += "📊 Ready to analyze and send signals!"
            
            # Run async function
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
            try:
                message_id = loop.run_until_complete(
                    self._send_message_async(message)
                )
                
                if message_id:
                    logger.info("✅ Startup message sent")
                    return True
                else:
                    logger.error("❌ Failed to send startup message")
                    return False
                    
            finally:
                loop.close()
                
        except Exception as e:
            logger.error(f"❌ Error sending startup message: {e}")
            return False

    def send_error_notification(self, error_message: str, module: str = None) -> bool:
        """Send error notification to admin"""
        try:
            if not self.bot:
                return False
            
            message = "🚨 **BOT ERROR ALERT** 🚨\n\n"
            if module:
                message += f"**Module:** {module}\n"
            message += f"**Error:** {error_message}\n"
            message += f"**Time:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')}\n\n"
            message += "Please check the bot logs for more details."
            
            # Run async function
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
            try:
                message_id = loop.run_until_complete(
                    self._send_message_async(message)
                )
                return message_id is not None
                    
            finally:
                loop.close()
                
        except Exception as e:
            logger.error(f"❌ Error sending error notification: {e}")
            return False

    def send_custom_message(self, message: str, chart_path: str = None) -> bool:
        """Send custom message"""
        try:
            if not self.bot:
                return False
            
            # Run async function
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
            try:
                message_id = loop.run_until_complete(
                    self._send_message_async(message, chart_path)
                )
                return message_id is not None
                    
            finally:
                loop.close()
                
        except Exception as e:
            logger.error(f"❌ Error sending custom message: {e}")
            return False

    def test_connection(self) -> bool:
        """Test Telegram bot connection"""
        try:
            if not self.bot:
                return False
            
            # Run async function
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
            try:
                bot_info = loop.run_until_complete(self.bot.get_me())
                logger.info(f"✅ Telegram connection test successful. Bot: @{bot_info.username}")
                return True
                    
            finally:
                loop.close()
                
        except Exception as e:
            logger.error(f"❌ Telegram connection test failed: {e}")
            return False
