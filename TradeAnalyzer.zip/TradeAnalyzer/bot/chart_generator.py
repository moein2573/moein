import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.patches import Rectangle
import seaborn as sns
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import os
import logging
from typing import Dict, Optional
import warnings
warnings.filterwarnings('ignore')

logger = logging.getLogger(__name__)

class ChartGenerator:
    def __init__(self, config: Dict):
        self.config = config
        self.chart_path = config.get('save_path', 'charts/')
        self.theme = config.get('theme', 'dark')
        self.width = config.get('width', 1200)
        self.height = config.get('height', 800)
        self.dpi = config.get('dpi', 100)
        
        # Create charts directory
        os.makedirs(self.chart_path, exist_ok=True)
        
        # Set style
        plt.style.use('dark_background' if self.theme == 'dark' else 'default')
        
        # Color schemes
        self.colors = {
            'dark': {
                'bg': '#0a0a0a',
                'grid': '#333333',
                'text': '#ffffff',
                'bullish': '#00ff88',
                'bearish': '#ff4444',
                'neutral': '#888888',
                'buy_signal': '#00ff00',
                'sell_signal': '#ff0000',
                'indicators': ['#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', '#ffeaa7']
            },
            'light': {
                'bg': '#ffffff',
                'grid': '#cccccc',
                'text': '#000000',
                'bullish': '#26a69a',
                'bearish': '#ef5350',
                'neutral': '#666666',
                'buy_signal': '#4caf50',
                'sell_signal': '#f44336',
                'indicators': ['#e74c3c', '#3498db', '#9b59b6', '#2ecc71', '#f39c12']
            }
        }

    def create_advanced_chart(self, data: pd.DataFrame, analysis: Dict, signal: Dict, 
                            symbol: str, timeframe: str) -> str:
        """Create comprehensive trading chart with multiple indicators"""
        try:
            # Prepare data
            if len(data) < 20:
                logger.warning(f"⚠️ Insufficient data for chart: {len(data)} candles")
                return None
            
            # Take recent data for better visualization
            chart_data = data.tail(100).copy()
            
            # Create figure with subplots
            fig = plt.figure(figsize=(self.width/100, self.height/100), dpi=self.dpi)
            fig.patch.set_facecolor(self.colors[self.theme]['bg'])
            
            # Define grid layout
            gs = fig.add_gridspec(4, 2, height_ratios=[3, 1, 1, 1], width_ratios=[3, 1], 
                                hspace=0.3, wspace=0.2)
            
            # Main price chart
            ax_main = fig.add_subplot(gs[0, :])
            self._plot_price_chart(ax_main, chart_data, signal, symbol, timeframe)
            
            # RSI subplot
            ax_rsi = fig.add_subplot(gs[1, 0])
            self._plot_rsi(ax_rsi, chart_data)
            
            # MACD subplot
            ax_macd = fig.add_subplot(gs[2, 0])
            self._plot_macd(ax_macd, chart_data)
            
            # Volume subplot
            ax_volume = fig.add_subplot(gs[3, 0])
            self._plot_volume(ax_volume, chart_data)
            
            # Strategy breakdown
            ax_strategy = fig.add_subplot(gs[1:, 1])
            self._plot_strategy_breakdown(ax_strategy, signal, analysis)
            
            # Style all axes
            for ax in [ax_main, ax_rsi, ax_macd, ax_volume, ax_strategy]:
                self._style_axis(ax)
            
            # Add title and info
            self._add_chart_info(fig, analysis, signal, symbol, timeframe)
            
            # Save chart
            filename = f"{symbol}_{timeframe}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
            filepath = os.path.join(self.chart_path, filename)
            
            plt.savefig(filepath, facecolor=self.colors[self.theme]['bg'], 
                       edgecolor='none', bbox_inches='tight', dpi=self.dpi)
            plt.close()
            
            logger.info(f"✅ Chart saved: {filepath}")
            return filepath
            
        except Exception as e:
            logger.error(f"❌ Error creating chart: {e}")
            return None

    def _plot_price_chart(self, ax, data: pd.DataFrame, signal: Dict, symbol: str, timeframe: str):
        """Plot main price chart with candlesticks and indicators"""
        try:
            # Prepare candlestick data
            dates = pd.to_datetime(data.index if 'Datetime' not in data.columns else data['Datetime'])
            opens = data['Open'].values
            highs = data['High'].values
            lows = data['Low'].values
            closes = data['Close'].values
            
            # Plot candlesticks
            for i in range(len(data)):
                color = self.colors[self.theme]['bullish'] if closes[i] >= opens[i] else self.colors[self.theme]['bearish']
                
                # Candle body
                height = abs(closes[i] - opens[i])
                bottom = min(closes[i], opens[i])
                ax.add_patch(Rectangle((i - 0.3, bottom), 0.6, height, facecolor=color, alpha=0.8))
                
                # Wicks
                ax.plot([i, i], [lows[i], highs[i]], color=color, linewidth=1, alpha=0.8)
            
            # Moving averages
            if 'SMA_20' in data.columns:
                ax.plot(range(len(data)), data['SMA_20'], color=self.colors[self.theme]['indicators'][0], 
                       linewidth=2, label='SMA 20', alpha=0.8)
            if 'SMA_50' in data.columns:
                ax.plot(range(len(data)), data['SMA_50'], color=self.colors[self.theme]['indicators'][1], 
                       linewidth=2, label='SMA 50', alpha=0.8)
            
            # Bollinger Bands
            if all(col in data.columns for col in ['BB_Upper', 'BB_Lower', 'BB_Middle']):
                ax.plot(range(len(data)), data['BB_Upper'], color=self.colors[self.theme]['indicators'][2], 
                       linewidth=1, linestyle='--', alpha=0.6)
                ax.plot(range(len(data)), data['BB_Lower'], color=self.colors[self.theme]['indicators'][2], 
                       linewidth=1, linestyle='--', alpha=0.6)
                ax.fill_between(range(len(data)), data['BB_Upper'], data['BB_Lower'], 
                               color=self.colors[self.theme]['indicators'][2], alpha=0.1)
            
            # SuperTrend
            if 'SuperTrend' in data.columns:
                st_color = []
                for i in range(len(data)):
                    if data['Close'].iloc[i] > data['SuperTrend'].iloc[i]:
                        st_color.append(self.colors[self.theme]['bullish'])
                    else:
                        st_color.append(self.colors[self.theme]['bearish'])
                
                for i in range(1, len(data)):
                    ax.plot([i-1, i], [data['SuperTrend'].iloc[i-1], data['SuperTrend'].iloc[i]], 
                           color=st_color[i], linewidth=3, alpha=0.7)
            
            # Ichimoku Cloud
            if all(col in data.columns for col in ['Ichimoku_A', 'Ichimoku_B']):
                ax.fill_between(range(len(data)), data['Ichimoku_A'], data['Ichimoku_B'], 
                               where=data['Ichimoku_A'] >= data['Ichimoku_B'], 
                               color=self.colors[self.theme]['bullish'], alpha=0.2, label='Ichimoku Cloud')
                ax.fill_between(range(len(data)), data['Ichimoku_A'], data['Ichimoku_B'], 
                               where=data['Ichimoku_A'] < data['Ichimoku_B'], 
                               color=self.colors[self.theme]['bearish'], alpha=0.2)
            
            # Support and Resistance
            if 'Support' in data.columns and 'Resistance' in data.columns:
                support_level = data['Support'].iloc[-1]
                resistance_level = data['Resistance'].iloc[-1]
                ax.axhline(y=support_level, color=self.colors[self.theme]['bullish'], 
                          linestyle=':', alpha=0.6, label='Support')
                ax.axhline(y=resistance_level, color=self.colors[self.theme]['bearish'], 
                          linestyle=':', alpha=0.6, label='Resistance')
            
            # Signal markers
            if signal and signal['type'] != 'HOLD':
                signal_color = self.colors[self.theme]['buy_signal'] if signal['type'] == 'BUY' else self.colors[self.theme]['sell_signal']
                signal_marker = '^' if signal['type'] == 'BUY' else 'v'
                
                ax.scatter(len(data)-1, closes[-1], color=signal_color, s=200, 
                          marker=signal_marker, zorder=10, edgecolors='white', linewidth=2)
                
                # Add signal labels
                ax.annotate(f"{signal['type']}\n{signal['confidence']:.1f}%", 
                           xy=(len(data)-1, closes[-1]), 
                           xytext=(10, 20 if signal['type'] == 'BUY' else -20), 
                           textcoords='offset points',
                           bbox=dict(boxstyle='round,pad=0.3', facecolor=signal_color, alpha=0.8),
                           arrowprops=dict(arrowstyle='->', color=signal_color),
                           fontsize=10, fontweight='bold', color='white')
            
            # Patterns annotations
            if 'patterns' in signal:
                pattern_text = ', '.join(signal['patterns'][:3])  # Show first 3 patterns
                if pattern_text:
                    ax.text(0.02, 0.98, f"Patterns: {pattern_text}", 
                           transform=ax.transAxes, fontsize=9, 
                           verticalalignment='top', 
                           bbox=dict(boxstyle='round,pad=0.3', 
                                   facecolor=self.colors[self.theme]['neutral'], alpha=0.7))
            
            # Formatting
            ax.set_title(f"{symbol} - {timeframe} | {signal.get('type', 'HOLD')} Signal", 
                        fontsize=16, fontweight='bold', color=self.colors[self.theme]['text'])
            ax.legend(loc='upper left', fontsize=8)
            ax.grid(True, alpha=0.3, color=self.colors[self.theme]['grid'])
            
        except Exception as e:
            logger.error(f"❌ Error plotting price chart: {e}")

    def _plot_rsi(self, ax, data: pd.DataFrame):
        """Plot RSI indicator"""
        try:
            if 'RSI' not in data.columns:
                return
            
            rsi_values = data['RSI'].values
            ax.plot(range(len(data)), rsi_values, color=self.colors[self.theme]['indicators'][0], 
                   linewidth=2, label='RSI')
            
            # Overbought/Oversold lines
            ax.axhline(y=70, color=self.colors[self.theme]['bearish'], linestyle='--', alpha=0.7)
            ax.axhline(y=30, color=self.colors[self.theme]['bullish'], linestyle='--', alpha=0.7)
            ax.axhline(y=50, color=self.colors[self.theme]['neutral'], linestyle='-', alpha=0.5)
            
            # Fill areas
            ax.fill_between(range(len(data)), 70, 100, alpha=0.2, color=self.colors[self.theme]['bearish'])
            ax.fill_between(range(len(data)), 0, 30, alpha=0.2, color=self.colors[self.theme]['bullish'])
            
            ax.set_ylim(0, 100)
            ax.set_ylabel('RSI', fontsize=10)
            ax.legend(loc='upper right', fontsize=8)
            
            # Current value annotation
            current_rsi = rsi_values[-1]
            ax.annotate(f'RSI: {current_rsi:.1f}', 
                       xy=(len(data)-1, current_rsi), 
                       xytext=(5, 0), textcoords='offset points',
                       fontsize=9, color=self.colors[self.theme]['text'])
            
        except Exception as e:
            logger.error(f"❌ Error plotting RSI: {e}")

    def _plot_macd(self, ax, data: pd.DataFrame):
        """Plot MACD indicator"""
        try:
            if not all(col in data.columns for col in ['MACD', 'MACD_Signal', 'MACD_Histogram']):
                return
            
            # MACD lines
            ax.plot(range(len(data)), data['MACD'], color=self.colors[self.theme]['indicators'][1], 
                   linewidth=2, label='MACD')
            ax.plot(range(len(data)), data['MACD_Signal'], color=self.colors[self.theme]['indicators'][2], 
                   linewidth=2, label='Signal')
            
            # Histogram
            histogram = data['MACD_Histogram'].values
            colors = [self.colors[self.theme]['bullish'] if h >= 0 else self.colors[self.theme]['bearish'] 
                     for h in histogram]
            ax.bar(range(len(data)), histogram, color=colors, alpha=0.7, width=0.8)
            
            # Zero line
            ax.axhline(y=0, color=self.colors[self.theme]['neutral'], linestyle='-', alpha=0.5)
            
            ax.set_ylabel('MACD', fontsize=10)
            ax.legend(loc='upper right', fontsize=8)
            
            # Current values annotation
            current_macd = data['MACD'].iloc[-1]
            current_signal = data['MACD_Signal'].iloc[-1]
            ax.annotate(f'MACD: {current_macd:.4f}\nSignal: {current_signal:.4f}', 
                       xy=(len(data)-1, current_macd), 
                       xytext=(5, 0), textcoords='offset points',
                       fontsize=8, color=self.colors[self.theme]['text'])
            
        except Exception as e:
            logger.error(f"❌ Error plotting MACD: {e}")

    def _plot_volume(self, ax, data: pd.DataFrame):
        """Plot volume with moving average"""
        try:
            if 'Volume' not in data.columns:
                return
            
            volume = data['Volume'].values
            colors = []
            
            for i in range(len(data)):
                if i == 0:
                    colors.append(self.colors[self.theme]['neutral'])
                else:
                    if data['Close'].iloc[i] >= data['Close'].iloc[i-1]:
                        colors.append(self.colors[self.theme]['bullish'])
                    else:
                        colors.append(self.colors[self.theme]['bearish'])
            
            ax.bar(range(len(data)), volume, color=colors, alpha=0.7)
            
            # Volume moving average
            if 'Volume_SMA' in data.columns:
                ax.plot(range(len(data)), data['Volume_SMA'], 
                       color=self.colors[self.theme]['indicators'][3], 
                       linewidth=2, label='Vol MA', alpha=0.8)
            
            ax.set_ylabel('Volume', fontsize=10)
            ax.legend(loc='upper right', fontsize=8)
            
            # Volume ratio annotation
            if 'Volume_Ratio' in data.columns:
                vol_ratio = data['Volume_Ratio'].iloc[-1]
                ax.annotate(f'Vol Ratio: {vol_ratio:.2f}x', 
                           xy=(len(data)-1, volume[-1]), 
                           xytext=(5, 5), textcoords='offset points',
                           fontsize=8, color=self.colors[self.theme]['text'])
            
        except Exception as e:
            logger.error(f"❌ Error plotting volume: {e}")

    def _plot_strategy_breakdown(self, ax, signal: Dict, analysis: Dict):
        """Plot strategy breakdown and signal details"""
        try:
            ax.clear()
            ax.set_xlim(0, 1)
            ax.set_ylim(0, 1)
            ax.set_title('Signal Analysis', fontsize=12, fontweight='bold')
            
            y_pos = 0.95
            
            # Signal summary
            signal_type = signal.get('type', 'HOLD')
            confidence = signal.get('confidence', 0)
            strength = signal.get('strength', 0)
            
            # Signal type with color
            signal_color = self.colors[self.theme]['buy_signal'] if signal_type == 'BUY' else \
                          self.colors[self.theme]['sell_signal'] if signal_type == 'SELL' else \
                          self.colors[self.theme]['neutral']
            
            ax.text(0.02, y_pos, f"Signal: {signal_type}", fontsize=14, fontweight='bold', 
                   color=signal_color)
            y_pos -= 0.08
            
            ax.text(0.02, y_pos, f"Confidence: {confidence:.1f}%", fontsize=10)
            y_pos -= 0.06
            
            ax.text(0.02, y_pos, f"Strength: {strength:.1f}", fontsize=10)
            y_pos -= 0.08
            
            # Risk management
            if 'entry_price' in signal:
                ax.text(0.02, y_pos, "Risk Management:", fontsize=11, fontweight='bold')
                y_pos -= 0.06
                
                ax.text(0.02, y_pos, f"Entry: ${signal['entry_price']:.4f}", fontsize=9)
                y_pos -= 0.05
                
                ax.text(0.02, y_pos, f"Stop Loss: ${signal['stop_loss']:.4f}", fontsize=9)
                y_pos -= 0.05
                
                ax.text(0.02, y_pos, f"Take Profit: ${signal['take_profit']:.4f}", fontsize=9)
                y_pos -= 0.05
                
                ax.text(0.02, y_pos, f"R/R: {signal.get('risk_reward', 0):.2f}", fontsize=9)
                y_pos -= 0.08
            
            # Strategy breakdown
            if 'strategy_breakdown' in signal:
                ax.text(0.02, y_pos, "Strategy Scores:", fontsize=11, fontweight='bold')
                y_pos -= 0.06
                
                for strategy, score in signal['strategy_breakdown'].items():
                    if isinstance(score, dict) and 'score' in score:
                        score_val = score['score']
                        color = self.colors[self.theme]['bullish'] if score_val > 0 else self.colors[self.theme]['bearish']
                        ax.text(0.02, y_pos, f"{strategy}: {score_val:+.1f}", fontsize=8, color=color)
                        y_pos -= 0.04
            
            # ML Prediction
            if 'ml_prediction' in signal and signal['ml_prediction']:
                ml_pred = signal['ml_prediction']
                y_pos -= 0.02
                ax.text(0.02, y_pos, "ML Prediction:", fontsize=11, fontweight='bold')
                y_pos -= 0.06
                
                direction = ml_pred.get('direction', 'neutral')
                pred_color = self.colors[self.theme]['bullish'] if direction == 'bullish' else self.colors[self.theme]['bearish']
                
                ax.text(0.02, y_pos, f"Direction: {direction}", fontsize=9, color=pred_color)
                y_pos -= 0.05
                
                ax.text(0.02, y_pos, f"Change: {ml_pred.get('predicted_change', 0):+.2f}%", fontsize=9)
                y_pos -= 0.05
            
            # Volume analysis
            if 'volume_analysis' in signal:
                vol_analysis = signal['volume_analysis']
                y_pos -= 0.02
                ax.text(0.02, y_pos, "Volume Analysis:", fontsize=11, fontweight='bold')
                y_pos -= 0.06
                
                vol_trend = vol_analysis.get('volume_trend', 'normal')
                trend_color = self.colors[self.theme]['bullish'] if vol_trend == 'high' else \
                             self.colors[self.theme]['bearish'] if vol_trend == 'low' else \
                             self.colors[self.theme]['neutral']
                
                ax.text(0.02, y_pos, f"Trend: {vol_trend}", fontsize=9, color=trend_color)
            
            ax.set_xticks([])
            ax.set_yticks([])
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            ax.spines['bottom'].set_visible(False)
            ax.spines['left'].set_visible(False)
            
        except Exception as e:
            logger.error(f"❌ Error plotting strategy breakdown: {e}")

    def _style_axis(self, ax):
        """Apply consistent styling to axis"""
        ax.set_facecolor(self.colors[self.theme]['bg'])
        ax.tick_params(colors=self.colors[self.theme]['text'], labelsize=8)
        ax.spines['bottom'].set_color(self.colors[self.theme]['grid'])
        ax.spines['top'].set_color(self.colors[self.theme]['grid'])
        ax.spines['right'].set_color(self.colors[self.theme]['grid'])
        ax.spines['left'].set_color(self.colors[self.theme]['grid'])
        ax.grid(True, alpha=0.3, color=self.colors[self.theme]['grid'])

    def _add_chart_info(self, fig, analysis: Dict, signal: Dict, symbol: str, timeframe: str):
        """Add chart information and timestamp"""
        try:
            info_text = f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            
            if 'patterns' in signal and signal['patterns']:
                info_text += f" | Patterns: {', '.join(signal['patterns'][:2])}"
            
            fig.text(0.99, 0.01, info_text, ha='right', va='bottom', 
                    fontsize=8, color=self.colors[self.theme]['text'], alpha=0.7)
            
        except Exception as e:
            logger.error(f"❌ Error adding chart info: {e}")

    def cleanup_old_charts(self):
        """Clean up old chart files"""
        try:
            cleanup_days = self.config.get('cleanup_days', 7)
            cutoff_time = datetime.now() - timedelta(days=cleanup_days)
            
            if not os.path.exists(self.chart_path):
                return
            
            deleted_count = 0
            for filename in os.listdir(self.chart_path):
                if filename.endswith('.png'):
                    filepath = os.path.join(self.chart_path, filename)
                    if os.path.getctime(filepath) < cutoff_time.timestamp():
                        os.remove(filepath)
                        deleted_count += 1
            
            if deleted_count > 0:
                logger.info(f"🧹 Cleaned up {deleted_count} old chart files")
            
        except Exception as e:
            logger.error(f"❌ Error cleaning up charts: {e}")
