import pandas as pd
import numpy as np
import yfinance as yf
from datetime import datetime
import logging
from typing import Optional, Dict, List
import warnings
warnings.filterwarnings('ignore')

# Technical Analysis imports
from ta.momentum import RSIIndicator, StochasticOscillator, WilliamsRIndicator
from ta.volatility import BollingerBands, AverageTrueRange, KeltnerChannel
from ta.trend import MACD, IchimokuIndicator, EMAIndicator, SMAIndicator, CCIIndicator, PSARIndicator
from ta.volume import ChaikinMoneyFlowIndicator, OnBalanceVolumeIndicator

# Bot module imports
from .strategies import TradingStrategies
from .utils import cache_data

# Try to import ML libraries with fallbacks
try:
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.preprocessing import StandardScaler
    from sklearn.model_selection import train_test_split
    ML_AVAILABLE = True
except ImportError:
    ML_AVAILABLE = False

logger = logging.getLogger(__name__)

class AdvancedTechnicalAnalyzer:
    def __init__(self, config: Dict):
        self.config = config
        self.strategies = TradingStrategies(config)
        self.data_cache = {}
        self.cache_timeout = 300  # 5 minutes
        
        # Initialize ML models if available
        self.ml_models = {}
        if ML_AVAILABLE:
            self._initialize_ml_models()
    
    def _initialize_ml_models(self):
        """Initialize machine learning models"""
        try:
            self.ml_models = {
                'price_predictor': RandomForestRegressor(n_estimators=100, random_state=42),
                'volatility_predictor': RandomForestRegressor(n_estimators=50, random_state=42),
                'scaler': StandardScaler()
            }
            logger.info("✅ ML models initialized")
        except Exception as e:
            logger.error(f"❌ Error initializing ML models: {e}")
            self.ml_models = {}

    @cache_data(timeout=300)
    def download_data(self, symbol: str, timeframe: str) -> Optional[pd.DataFrame]:
        """Download market data with caching"""
        try:
            from main import config
            tf_config = config['timeframes'][timeframe]
            
            # Download data
            data = yf.download(
                symbol,
                period=tf_config['period'],
                interval=tf_config['interval'],
                progress=False,
                auto_adjust=True
            )
            
            if data.empty:
                logger.warning(f"⚠️ No data received for {symbol}")
                return None
            
            # Handle multi-level columns
            if isinstance(data.columns, pd.MultiIndex):
                data.columns = data.columns.droplevel(1)
            
            # Validate required columns
            required_columns = ['Open', 'High', 'Low', 'Close', 'Volume']
            if not all(col in data.columns for col in required_columns):
                logger.error(f"❌ Missing required columns for {symbol}")
                return None
            
            # Reset index and clean data
            data = data.reset_index()
            data = data.dropna()
            
            logger.info(f"✅ Downloaded {len(data)} candles for {symbol} ({timeframe})")
            return data
            
        except Exception as e:
            logger.error(f"❌ Error downloading data for {symbol}: {e}")
            return None

    def calculate_advanced_indicators(self, data: pd.DataFrame) -> pd.DataFrame:
        """Calculate comprehensive technical indicators"""
        try:
            df = data.copy()
            close = df['Close']
            high = df['High']
            low = df['Low']
            volume = df['Volume']
            
            # Momentum Indicators
            df['RSI'] = RSIIndicator(close=close, window=14).rsi()
            df['Williams_R'] = WilliamsRIndicator(high=high, low=low, close=close, lbp=14).williams_r()
            
            # Stochastic
            stoch = StochasticOscillator(high=high, low=low, close=close)
            df['Stoch_K'] = stoch.stoch()
            df['Stoch_D'] = stoch.stoch_signal()
            
            # CCI
            df['CCI'] = CCIIndicator(high=high, low=low, close=close, window=20).cci()
            
            # Trend Indicators
            macd = MACD(close)
            df['MACD'] = macd.macd()
            df['MACD_Signal'] = macd.macd_signal()
            df['MACD_Histogram'] = macd.macd_diff()
            
            # Moving Averages
            df['SMA_10'] = SMAIndicator(close, window=10).sma_indicator()
            df['SMA_20'] = SMAIndicator(close, window=20).sma_indicator()
            df['SMA_50'] = SMAIndicator(close, window=50).sma_indicator()
            df['SMA_200'] = SMAIndicator(close, window=200).sma_indicator()
            
            df['EMA_12'] = EMAIndicator(close, window=12).ema_indicator()
            df['EMA_26'] = EMAIndicator(close, window=26).ema_indicator()
            df['EMA_50'] = EMAIndicator(close, window=50).ema_indicator()
            
            # Ichimoku
            ichimoku = IchimokuIndicator(high=high, low=low)
            df['Ichimoku_A'] = ichimoku.ichimoku_a()
            df['Ichimoku_B'] = ichimoku.ichimoku_b()
            df['Ichimoku_Base'] = ichimoku.ichimoku_base_line()
            df['Ichimoku_Conversion'] = ichimoku.ichimoku_conversion_line()
            
            # Volatility Indicators
            df['ATR'] = AverageTrueRange(high, low, close).average_true_range()
            
            # Bollinger Bands
            bollinger = BollingerBands(close)
            df['BB_Upper'] = bollinger.bollinger_hband()
            df['BB_Lower'] = bollinger.bollinger_lband()
            df['BB_Middle'] = bollinger.bollinger_mavg()
            df['BB_Width'] = ((df['BB_Upper'] - df['BB_Lower']) / df['BB_Middle']) * 100
            df['BB_Position'] = (close - df['BB_Lower']) / (df['BB_Upper'] - df['BB_Lower'])
            
            # Keltner Channel
            keltner = KeltnerChannel(high, low, close)
            df['KC_Upper'] = keltner.keltner_channel_hband()
            df['KC_Lower'] = keltner.keltner_channel_lband()
            df['KC_Middle'] = keltner.keltner_channel_mband()
            
            # SuperTrend
            df = self._calculate_supertrend(df)
            
            # Parabolic SAR
            try:
                df['PSAR'] = PSARIndicator(high=high, low=low, close=close).psar()
            except:
                df['PSAR'] = close * 0.98  # Fallback
            
            # Volume Indicators
            df['Volume_SMA'] = SMAIndicator(volume, window=20).sma_indicator()
            df['Volume_Ratio'] = volume / df['Volume_SMA']
            df['CMF'] = ChaikinMoneyFlowIndicator(high, low, close, volume).chaikin_money_flow()
            df['OBV'] = OnBalanceVolumeIndicator(close, volume).on_balance_volume()
            
            # Price Action Indicators
            df['Price_Change'] = close.pct_change()
            df['Volatility'] = df['Price_Change'].rolling(window=20).std()
            df['True_Range'] = np.maximum(high - low, 
                                        np.maximum(abs(high - close.shift(1)),
                                                 abs(low - close.shift(1))))
            
            # Support and Resistance
            df = self._calculate_support_resistance(df)
            
            logger.info("✅ Advanced indicators calculated successfully")
            return df
            
        except Exception as e:
            logger.error(f"❌ Error calculating indicators: {e}")
            return data

    def _calculate_supertrend(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate SuperTrend indicator"""
        try:
            period = 10
            multiplier = 3.0
            
            hl2 = (df['High'] + df['Low']) / 2
            atr = df['ATR']
            
            upper_band = hl2 + (multiplier * atr)
            lower_band = hl2 - (multiplier * atr)
            
            # Initialize arrays
            final_upper_band = upper_band.copy()
            final_lower_band = lower_band.copy()
            supertrend = pd.Series(index=df.index, dtype=float)
            
            for i in range(1, len(df)):
                # Final Upper Band
                if upper_band.iloc[i] < final_upper_band.iloc[i-1] or df['Close'].iloc[i-1] > final_upper_band.iloc[i-1]:
                    final_upper_band.iloc[i] = upper_band.iloc[i]
                else:
                    final_upper_band.iloc[i] = final_upper_band.iloc[i-1]
                
                # Final Lower Band
                if lower_band.iloc[i] > final_lower_band.iloc[i-1] or df['Close'].iloc[i-1] < final_lower_band.iloc[i-1]:
                    final_lower_band.iloc[i] = lower_band.iloc[i]
                else:
                    final_lower_band.iloc[i] = final_lower_band.iloc[i-1]
                
                # SuperTrend
                if i == 1:
                    supertrend.iloc[i] = final_upper_band.iloc[i]
                else:
                    if supertrend.iloc[i-1] == final_upper_band.iloc[i-1] and df['Close'].iloc[i] <= final_upper_band.iloc[i]:
                        supertrend.iloc[i] = final_upper_band.iloc[i]
                    elif supertrend.iloc[i-1] == final_upper_band.iloc[i-1] and df['Close'].iloc[i] > final_upper_band.iloc[i]:
                        supertrend.iloc[i] = final_lower_band.iloc[i]
                    elif supertrend.iloc[i-1] == final_lower_band.iloc[i-1] and df['Close'].iloc[i] >= final_lower_band.iloc[i]:
                        supertrend.iloc[i] = final_lower_band.iloc[i]
                    elif supertrend.iloc[i-1] == final_lower_band.iloc[i-1] and df['Close'].iloc[i] < final_lower_band.iloc[i]:
                        supertrend.iloc[i] = final_upper_band.iloc[i]
            
            df['SuperTrend'] = supertrend
            df['ST_Upper'] = final_upper_band
            df['ST_Lower'] = final_lower_band
            
            return df
            
        except Exception as e:
            logger.error(f"❌ Error calculating SuperTrend: {e}")
            df['SuperTrend'] = df['Close']
            return df

    def _calculate_support_resistance(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate dynamic support and resistance levels"""
        try:
            window = 20
            df['Support'] = df['Low'].rolling(window=window).min()
            df['Resistance'] = df['High'].rolling(window=window).max()
            
            # Pivot points
            df['Pivot'] = (df['High'] + df['Low'] + df['Close']) / 3
            df['R1'] = 2 * df['Pivot'] - df['Low']
            df['S1'] = 2 * df['Pivot'] - df['High']
            df['R2'] = df['Pivot'] + (df['High'] - df['Low'])
            df['S2'] = df['Pivot'] - (df['High'] - df['Low'])
            
            return df
            
        except Exception as e:
            logger.error(f"❌ Error calculating support/resistance: {e}")
            return df

    def detect_patterns(self, data: pd.DataFrame) -> List[str]:
        """Detect candlestick and chart patterns"""
        patterns = []
        
        if len(data) < 5:
            return patterns
        
        try:
            recent_data = data.tail(5)
            current = recent_data.iloc[-1]
            prev1 = recent_data.iloc[-2]
            prev2 = recent_data.iloc[-3] if len(recent_data) >= 3 else None
            
            # Candlestick patterns
            body_current = abs(current['Close'] - current['Open'])
            body_prev = abs(prev1['Close'] - prev1['Open'])
            
            range_current = current['High'] - current['Low']
            upper_shadow = current['High'] - max(current['Close'], current['Open'])
            lower_shadow = min(current['Close'], current['Open']) - current['Low']
            
            # Hammer
            if (lower_shadow > 2 * body_current and upper_shadow < body_current and 
                range_current > 0):
                patterns.append('hammer')
            
            # Shooting Star
            if (upper_shadow > 2 * body_current and lower_shadow < body_current and
                range_current > 0):
                patterns.append('shooting_star')
            
            # Doji
            if body_current < range_current * 0.1 and range_current > 0:
                patterns.append('doji')
            
            # Engulfing patterns
            if prev2 is not None:
                # Bullish Engulfing
                if (prev1['Close'] < prev1['Open'] and current['Close'] > current['Open'] and
                    current['Close'] > prev1['Open'] and current['Open'] < prev1['Close']):
                    patterns.append('bullish_engulfing')
                
                # Bearish Engulfing
                if (prev1['Close'] > prev1['Open'] and current['Close'] < current['Open'] and
                    current['Close'] < prev1['Open'] and current['Open'] > prev1['Close']):
                    patterns.append('bearish_engulfing')
            
            # Chart patterns
            if len(data) >= 20:
                patterns.extend(self._detect_chart_patterns(data))
            
        except Exception as e:
            logger.error(f"❌ Error detecting patterns: {e}")
        
        return patterns

    def _detect_chart_patterns(self, data: pd.DataFrame) -> List[str]:
        """Detect chart patterns like head and shoulders, triangles, etc."""
        patterns = []
        
        try:
            recent_data = data.tail(20)
            highs = recent_data['High']
            lows = recent_data['Low']
            closes = recent_data['Close']
            
            # Trend detection
            if closes.iloc[-1] > closes.iloc[-10] > closes.iloc[-20]:
                patterns.append('uptrend')
            elif closes.iloc[-1] < closes.iloc[-10] < closes.iloc[-20]:
                patterns.append('downtrend')
            
            # Breakout patterns
            if 'BB_Upper' in data.columns and 'BB_Lower' in data.columns:
                current_close = closes.iloc[-1]
                bb_upper = data['BB_Upper'].iloc[-1]
                bb_lower = data['BB_Lower'].iloc[-1]
                
                if current_close > bb_upper:
                    patterns.append('breakout_up')
                elif current_close < bb_lower:
                    patterns.append('breakout_down')
            
            # Triangle patterns (simplified)
            if len(highs) >= 10:
                recent_highs = highs.tail(10)
                recent_lows = lows.tail(10)
                
                high_trend = np.polyfit(range(len(recent_highs)), recent_highs, 1)[0]
                low_trend = np.polyfit(range(len(recent_lows)), recent_lows, 1)[0]
                
                if abs(high_trend) < 0.001 and abs(low_trend) < 0.001:
                    patterns.append('rectangle')
                elif high_trend < 0 and low_trend > 0:
                    patterns.append('triangle_symmetrical')
                elif high_trend < 0 and abs(low_trend) < 0.001:
                    patterns.append('triangle_descending')
                elif abs(high_trend) < 0.001 and low_trend > 0:
                    patterns.append('triangle_ascending')
            
        except Exception as e:
            logger.error(f"❌ Error detecting chart patterns: {e}")
        
        return patterns

    def analyze_volume(self, data: pd.DataFrame) -> Dict:
        """Advanced volume analysis"""
        try:
            if 'Volume_Ratio' not in data.columns:
                return {'volume_trend': 'normal', 'volume_ratio': 1.0, 'cmf': 0}
            
            current_volume_ratio = data['Volume_Ratio'].iloc[-1]
            cmf = data['CMF'].iloc[-1] if 'CMF' in data.columns else 0
            
            # Volume trend
            volume_trend = 'high' if current_volume_ratio > 1.5 else 'low' if current_volume_ratio < 0.8 else 'normal'
            
            # Price-Volume divergence
            price_change = data['Close'].pct_change(5).iloc[-1]
            volume_change = data['Volume_Ratio'].pct_change(5).iloc[-1]
            
            divergence = False
            if price_change > 0.02 and volume_change < -0.2:
                divergence = True  # Price up, volume down
            elif price_change < -0.02 and volume_change < -0.2:
                divergence = True  # Price down, volume down
            
            return {
                'volume_trend': volume_trend,
                'volume_ratio': round(current_volume_ratio, 2),
                'cmf': round(cmf, 4),
                'divergence': divergence,
                'obv_trend': self._get_obv_trend(data)
            }
            
        except Exception as e:
            logger.error(f"❌ Error analyzing volume: {e}")
            return {'volume_trend': 'normal', 'volume_ratio': 1.0, 'cmf': 0}

    def _get_obv_trend(self, data: pd.DataFrame) -> str:
        """Get On-Balance Volume trend"""
        try:
            if 'OBV' not in data.columns or len(data) < 10:
                return 'neutral'
            
            obv_recent = data['OBV'].tail(10)
            obv_trend = np.polyfit(range(len(obv_recent)), obv_recent, 1)[0]
            
            if obv_trend > 0:
                return 'bullish'
            elif obv_trend < 0:
                return 'bearish'
            else:
                return 'neutral'
                
        except:
            return 'neutral'

    def get_ml_prediction(self, data: pd.DataFrame) -> Optional[Dict]:
        """Get machine learning prediction if available"""
        if not ML_AVAILABLE or not self.ml_models:
            return None
        
        try:
            # Prepare features
            features = self._prepare_ml_features(data)
            if features is None or len(features) < 30:
                return None
            
            # Split data
            X = features.drop(['target'], axis=1).fillna(0)
            y = features['target'].fillna(0)
            
            if len(X) < 30:
                return None
            
            # Train model with recent data
            X_train, X_test, y_train, y_test = train_test_split(
                X.tail(100), y.tail(100), test_size=0.2, random_state=42
            )
            
            # Scale features
            X_train_scaled = self.ml_models['scaler'].fit_transform(X_train)
            X_test_scaled = self.ml_models['scaler'].transform(X_test)
            
            # Train and predict
            self.ml_models['price_predictor'].fit(X_train_scaled, y_train)
            
            # Make prediction for next period
            last_features = X.tail(1)
            last_features_scaled = self.ml_models['scaler'].transform(last_features)
            prediction = self.ml_models['price_predictor'].predict(last_features_scaled)[0]
            
            # Calculate confidence
            feature_importance = self.ml_models['price_predictor'].feature_importances_
            confidence = np.mean(feature_importance) * 100
            
            current_price = data['Close'].iloc[-1]
            predicted_change = (prediction - current_price) / current_price * 100
            
            return {
                'predicted_price': round(prediction, 4),
                'predicted_change': round(predicted_change, 2),
                'confidence': round(confidence, 1),
                'direction': 'bullish' if predicted_change > 0 else 'bearish',
                'strength': min(abs(predicted_change) * 10, 100)
            }
            
        except Exception as e:
            logger.error(f"❌ ML prediction error: {e}")
            return None

    def _prepare_ml_features(self, data: pd.DataFrame) -> Optional[pd.DataFrame]:
        """Prepare features for ML model"""
        try:
            if len(data) < 50:
                return None
            
            df = data.copy()
            
            # Target: next period return
            df['target'] = df['Close'].shift(-1) / df['Close'] - 1
            
            # Technical features
            df['rsi_norm'] = df['RSI'] / 100
            df['bb_position'] = df['BB_Position'] if 'BB_Position' in df.columns else 0.5
            df['macd_hist_norm'] = df['MACD_Histogram'] / df['Close']
            df['volume_norm'] = df['Volume_Ratio'] if 'Volume_Ratio' in df.columns else 1
            df['atr_norm'] = df['ATR'] / df['Close']
            df['price_change_5'] = df['Close'].pct_change(5)
            df['price_change_10'] = df['Close'].pct_change(10)
            df['volatility_norm'] = df['Volatility'] if 'Volatility' in df.columns else 0
            
            # Moving average ratios
            df['sma_ratio_10_20'] = df['SMA_10'] / df['SMA_20'] if 'SMA_20' in df.columns else 1
            df['sma_ratio_20_50'] = df['SMA_20'] / df['SMA_50'] if 'SMA_50' in df.columns else 1
            
            # Select features
            feature_cols = [
                'rsi_norm', 'bb_position', 'macd_hist_norm', 'volume_norm',
                'atr_norm', 'price_change_5', 'price_change_10', 'volatility_norm',
                'sma_ratio_10_20', 'sma_ratio_20_50', 'target'
            ]
            
            return df[feature_cols].dropna()
            
        except Exception as e:
            logger.error(f"❌ Error preparing ML features: {e}")
            return None

    def analyze_symbol(self, symbol: str, timeframe: str) -> Optional[Dict]:
        """Complete analysis of a symbol"""
        try:
            logger.info(f"🔍 Analyzing {symbol} - {timeframe}")
            
            # Download data
            data = self.download_data(symbol, timeframe)
            if data is None or len(data) < 50:
                logger.warning(f"⚠️ Insufficient data for {symbol}")
                return None
            
            # Calculate indicators
            data = self.calculate_advanced_indicators(data)
            
            # Detect patterns
            patterns = self.detect_patterns(data)
            
            # Analyze volume
            volume_analysis = self.analyze_volume(data)
            
            # Get ML prediction
            ml_prediction = self.get_ml_prediction(data)
            
            # Get current market data
            current_row = data.iloc[-1]
            
            return {
                'symbol': symbol,
                'timeframe': timeframe,
                'data': data,
                'current_price': current_row['Close'],
                'patterns': patterns,
                'volume_analysis': volume_analysis,
                'ml_prediction': ml_prediction,
                'timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"❌ Error analyzing {symbol}: {e}")
            return None

    def generate_signal(self, analysis_result: Dict, symbol: str, timeframe: str) -> Optional[Dict]:
        """Generate trading signal from analysis"""
        try:
            data = analysis_result['data']
            current_row = data.iloc[-1]
            patterns = analysis_result['patterns']
            volume_analysis = analysis_result['volume_analysis']
            ml_prediction = analysis_result['ml_prediction']
            
            # Get signals from all strategies
            strategy_signals = self.strategies.get_all_signals(
                current_row, patterns, volume_analysis, ml_prediction
            )
            
            # Combine signals
            combined_signal = self.strategies.combine_signals(strategy_signals)
            
            if combined_signal['type'] == 'HOLD':
                return combined_signal
            
            # Calculate risk management levels
            atr = current_row['ATR'] if 'ATR' in current_row else current_row['Close'] * 0.02
            current_price = current_row['Close']
            
            if combined_signal['type'] == 'BUY':
                stop_loss = current_price - (atr * 2)
                take_profit = current_price + (atr * 3)
            else:  # SELL
                stop_loss = current_price + (atr * 2)
                take_profit = current_price - (atr * 3)
            
            risk_reward = abs(take_profit - current_price) / abs(current_price - stop_loss)
            
            # Position sizing
            risk_percent = self.config.get('default_risk_percent', 2.0)
            position_size = risk_percent / (abs(current_price - stop_loss) / current_price * 100)
            
            return {
                'type': combined_signal['type'],
                'strength': combined_signal['strength'],
                'confidence': combined_signal['confidence'],
                'entry_price': current_price,
                'stop_loss': stop_loss,
                'take_profit': take_profit,
                'risk_reward': round(risk_reward, 2),
                'position_size': round(position_size, 2),
                'strategy_breakdown': strategy_signals,
                'ml_prediction': ml_prediction,
                'patterns': patterns,
                'volume_analysis': volume_analysis
            }
            
        except Exception as e:
            logger.error(f"❌ Error generating signal: {e}")
            return None

    def get_current_price(self, symbol: str) -> Optional[Dict]:
        """Get current price for a symbol"""
        try:
            ticker = yf.Ticker(symbol)
            data = ticker.history(period="1d", interval="1m")
            
            if data.empty:
                return None
            
            current_price = data['Close'].iloc[-1]
            return {
                'price': current_price,
                'timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"❌ Error getting current price for {symbol}: {e}")
            return None
