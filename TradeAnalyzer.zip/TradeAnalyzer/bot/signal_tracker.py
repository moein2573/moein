import sqlite3
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import pandas as pd

logger = logging.getLogger(__name__)

class SignalTracker:
    def __init__(self, db_manager, config: Dict):
        self.db_manager = db_manager
        self.config = config
        self.max_open_signals = config.get('max_open_signals', 10)
        self.signal_timeout_hours = config.get('signal_timeout_hours', 72)
        
        # Initialize tracking tables
        self._initialize_tables()

    def _initialize_tables(self):
        """Initialize database tables for signal tracking"""
        # Tables are now created by the main database manager
        logger.info("✅ Signal tracking tables available")

    def should_send_signal(self, symbol: str, timeframe: str, signal_type: str) -> bool:
        """Check if we should send a signal based on history and limits"""
        try:
            # Check if we have too many open signals
            open_count = self._get_open_signals_count()
            if open_count >= self.max_open_signals:
                logger.info(f"⚠️ Max open signals reached ({open_count}/{self.max_open_signals})")
                return False
            
            # Check recent signals for same symbol/timeframe
            recent_signals = self.db_manager.fetch_query("""
                SELECT created_at FROM signals 
                WHERE symbol = %s AND timeframe = %s AND signal_type = %s
                AND created_at > NOW() - INTERVAL '1 hour'
                ORDER BY created_at DESC LIMIT 1
            """, (symbol, timeframe, signal_type))
            
            if recent_signals:
                logger.info(f"⏭️ Recent signal exists for {symbol} {timeframe} {signal_type}")
                return False
            
            # Check if we have an open signal for this symbol/timeframe
            open_signal = self.db_manager.fetch_query("""
                SELECT id FROM signals 
                WHERE symbol = %s AND timeframe = %s AND status = 'OPEN'
                LIMIT 1
            """, (symbol, timeframe))
            
            if open_signal:
                logger.info(f"⏭️ Open signal exists for {symbol} {timeframe}")
                return False
            
            return True
            
        except Exception as e:
            logger.error(f"❌ Error checking signal permissions: {e}")
            return False

    def _get_open_signals_count(self) -> int:
        """Get count of currently open signals"""
        try:
            result = self.db_manager.fetch_query("""
                SELECT COUNT(*) as count FROM signals WHERE status = 'OPEN'
            """)
            return result[0]['count'] if result else 0
        except:
            return 0

    def create_signal_record(self, symbol: str, timeframe: str, signal_data: Dict, 
                           chart_path: str = None) -> Dict:
        """Create a complete signal record"""
        try:
            return {
                'symbol': symbol,
                'timeframe': timeframe,
                'signal_type': signal_data['type'],
                'entry_price': signal_data['entry_price'],
                'stop_loss': signal_data.get('stop_loss'),
                'take_profit': signal_data.get('take_profit'),
                'confidence': signal_data.get('confidence', 0),
                'strength': signal_data.get('strength', 0),
                'risk_reward': signal_data.get('risk_reward'),
                'position_size': signal_data.get('position_size'),
                'patterns': json.dumps(signal_data.get('patterns', [])),
                'volume_analysis': json.dumps(signal_data.get('volume_analysis', {})),
                'strategy_breakdown': json.dumps(signal_data.get('strategy_breakdown', {})),
                'ml_prediction': json.dumps(signal_data.get('ml_prediction', {})),
                'chart_path': chart_path,
                'created_at': datetime.now().isoformat()
            }
        except Exception as e:
            logger.error(f"❌ Error creating signal record: {e}")
            return {}

    def save_signal(self, signal_record: Dict) -> Optional[int]:
        """Save signal to database"""
        try:
            query = """
                INSERT INTO signals (
                    symbol, timeframe, signal_type, entry_price, stop_loss, take_profit,
                    confidence, strength, risk_reward, position_size, patterns,
                    volume_analysis, strategy_breakdown, ml_prediction, chart_path
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING id
            """
            
            values = (
                signal_record['symbol'],
                signal_record['timeframe'],
                signal_record['signal_type'],
                signal_record['entry_price'],
                signal_record.get('stop_loss'),
                signal_record.get('take_profit'),
                signal_record.get('confidence'),
                signal_record.get('strength'),
                signal_record.get('risk_reward'),
                signal_record.get('position_size'),
                signal_record.get('patterns'),
                signal_record.get('volume_analysis'),
                signal_record.get('strategy_breakdown'),
                signal_record.get('ml_prediction'),
                signal_record.get('chart_path')
            )
            
            signal_id = self.db_manager.execute_query(query, values, return_id=True)
            logger.info(f"✅ Signal saved with ID: {signal_id}")
            return signal_id
            
        except Exception as e:
            logger.error(f"❌ Error saving signal: {e}")
            return None

    def get_open_signals(self) -> List[Dict]:
        """Get all open signals"""
        try:
            signals = self.db_manager.fetch_query("""
                SELECT * FROM signals 
                WHERE status = 'OPEN' 
                ORDER BY created_at DESC
            """)
            
            return [dict(signal) for signal in signals] if signals else []
            
        except Exception as e:
            logger.error(f"❌ Error getting open signals: {e}")
            return []

    def check_signal_status(self, signal: Dict, current_price: float) -> Dict:
        """Check if signal targets are hit and update status"""
        try:
            signal_id = signal['id']
            signal_type = signal['signal_type']
            entry_price = signal['entry_price']
            stop_loss = signal.get('stop_loss')
            take_profit = signal.get('take_profit')
            
            status_update = {
                'status': 'OPEN',
                'close_price': None,
                'pnl_percent': 0,
                'pnl_points': 0,
                'close_reason': None
            }
            
            # Calculate unrealized PnL
            if signal_type == 'BUY':
                pnl_points = current_price - entry_price
                pnl_percent = (pnl_points / entry_price) * 100
                
                # Check targets
                if take_profit and current_price >= take_profit:
                    status_update.update({
                        'status': 'CLOSED_PROFIT',
                        'close_price': current_price,
                        'close_reason': 'Take Profit Hit'
                    })
                elif stop_loss and current_price <= stop_loss:
                    status_update.update({
                        'status': 'CLOSED_LOSS',
                        'close_price': current_price,
                        'close_reason': 'Stop Loss Hit'
                    })
                    
            else:  # SELL
                pnl_points = entry_price - current_price
                pnl_percent = (pnl_points / entry_price) * 100
                
                # Check targets
                if take_profit and current_price <= take_profit:
                    status_update.update({
                        'status': 'CLOSED_PROFIT',
                        'close_price': current_price,
                        'close_reason': 'Take Profit Hit'
                    })
                elif stop_loss and current_price >= stop_loss:
                    status_update.update({
                        'status': 'CLOSED_LOSS',
                        'close_price': current_price,
                        'close_reason': 'Stop Loss Hit'
                    })
            
            status_update['pnl_percent'] = round(pnl_percent, 2)
            status_update['pnl_points'] = round(pnl_points, 6)
            
            # Check for timeout
            created_at = datetime.fromisoformat(signal['created_at'].replace('Z', '+00:00'))
            hours_elapsed = (datetime.now() - created_at).total_seconds() / 3600
            
            if hours_elapsed > self.signal_timeout_hours and status_update['status'] == 'OPEN':
                status_update.update({
                    'status': 'EXPIRED',
                    'close_price': current_price,
                    'close_reason': 'Signal Timeout'
                })
            
            # Update database if status changed
            if status_update['status'] != 'OPEN':
                self._update_signal_status(signal_id, status_update)
            
            return status_update
            
        except Exception as e:
            logger.error(f"❌ Error checking signal status: {e}")
            return {'status': 'OPEN', 'close_price': None, 'pnl_percent': 0, 'pnl_points': 0}

    def _update_signal_status(self, signal_id: int, status_update: Dict):
        """Update signal status in database"""
        try:
            query = """
                UPDATE signals 
                SET status = ?, close_price = ?, pnl_percent = ?, pnl_points = ?, 
                    close_reason = ?, closed_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """
            
            values = (
                status_update['status'],
                status_update['close_price'],
                status_update['pnl_percent'],
                status_update['pnl_points'],
                status_update['close_reason'],
                signal_id
            )
            
            self.db_manager.execute_query(query, values)
            logger.info(f"✅ Signal {signal_id} status updated to {status_update['status']}")
            
        except Exception as e:
            logger.error(f"❌ Error updating signal status: {e}")

    def get_last_analysis_time(self, symbol: str, timeframe: str) -> Optional[datetime]:
        """Get last analysis time for symbol-timeframe"""
        try:
            result = self.db_manager.fetch_query("""
                SELECT analyzed_at FROM analysis_history 
                WHERE symbol = %s AND timeframe = %s 
                ORDER BY analyzed_at DESC LIMIT 1
            """, (symbol, timeframe))
            
            if result:
                return datetime.fromisoformat(result[0]['analyzed_at'])
            return None
            
        except Exception as e:
            logger.error(f"❌ Error getting last analysis time: {e}")
            return None

    def log_analysis(self, symbol: str, timeframe: str, signal_generated: bool = False, 
                    analysis_data: Dict = None):
        """Log analysis attempt"""
        try:
            query = """
                INSERT INTO analysis_history (symbol, timeframe, signal_generated, analysis_data)
                VALUES (%s, %s, %s, %s)
            """
            
            values = (symbol, timeframe, signal_generated, json.dumps(analysis_data) if analysis_data else None)
            self.db_manager.execute_query(query, values)
            
        except Exception as e:
            logger.error(f"❌ Error logging analysis: {e}")

    def generate_performance_report(self, days: int = 7) -> Optional[Dict]:
        """Generate performance report for last N days"""
        try:
            end_date = datetime.now()
            start_date = end_date - timedelta(days=days)
            
            # Get closed signals in date range
            signals = self.db_manager.fetch_query("""
                SELECT * FROM signals 
                WHERE status IN ('CLOSED_PROFIT', 'CLOSED_LOSS', 'EXPIRED')
                AND closed_at >= %s AND closed_at <= %s
                ORDER BY closed_at DESC
            """, (start_date.isoformat(), end_date.isoformat()))
            
            if not signals:
                return None
            
            # Calculate metrics
            total_signals = len(signals)
            winning_signals = len([s for s in signals if s['pnl_percent'] > 0])
            losing_signals = len([s for s in signals if s['pnl_percent'] < 0])
            
            total_pnl = sum(s['pnl_percent'] for s in signals)
            win_rate = (winning_signals / total_signals) * 100 if total_signals > 0 else 0
            
            wins = [s['pnl_percent'] for s in signals if s['pnl_percent'] > 0]
            losses = [abs(s['pnl_percent']) for s in signals if s['pnl_percent'] < 0]
            
            avg_win = sum(wins) / len(wins) if wins else 0
            avg_loss = sum(losses) / len(losses) if losses else 0
            
            profit_factor = (avg_win * winning_signals) / (avg_loss * losing_signals) if avg_loss > 0 and losing_signals > 0 else 0
            
            # Calculate drawdown
            running_pnl = 0
            peak = 0
            max_drawdown = 0
            
            for signal in reversed(signals):
                running_pnl += signal['pnl_percent']
                if running_pnl > peak:
                    peak = running_pnl
                drawdown = peak - running_pnl
                if drawdown > max_drawdown:
                    max_drawdown = drawdown
            
            # Best and worst trades
            best_trade = max(signals, key=lambda x: x['pnl_percent'])
            worst_trade = min(signals, key=lambda x: x['pnl_percent'])
            
            # Strategy performance
            strategy_performance = {}
            for signal in signals:
                try:
                    breakdown = json.loads(signal.get('strategy_breakdown', '{}'))
                    for strategy, data in breakdown.items():
                        if strategy not in strategy_performance:
                            strategy_performance[strategy] = {'signals': 0, 'pnl': 0}
                        strategy_performance[strategy]['signals'] += 1
                        strategy_performance[strategy]['pnl'] += signal['pnl_percent']
                except:
                    continue
            
            report = {
                'period': f"{start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}",
                'summary': {
                    'total_signals': total_signals,
                    'winning_signals': winning_signals,
                    'losing_signals': losing_signals,
                    'win_rate': round(win_rate, 1),
                    'total_pnl': round(total_pnl, 2),
                    'avg_win': round(avg_win, 2),
                    'avg_loss': round(avg_loss, 2),
                    'profit_factor': round(profit_factor, 2),
                    'max_drawdown': round(max_drawdown, 2)
                },
                'best_trade': {
                    'symbol': best_trade['symbol'],
                    'pnl': round(best_trade['pnl_percent'], 2),
                    'date': best_trade['closed_at']
                },
                'worst_trade': {
                    'symbol': worst_trade['symbol'],
                    'pnl': round(worst_trade['pnl_percent'], 2),
                    'date': worst_trade['closed_at']
                },
                'strategy_performance': {k: {
                    'signals': v['signals'],
                    'avg_pnl': round(v['pnl'] / v['signals'], 2)
                } for k, v in strategy_performance.items()}
            }
            
            return report
            
        except Exception as e:
            logger.error(f"❌ Error generating performance report: {e}")
            return None

    def cleanup_old_signals(self, days: int = 90):
        """Clean up old signal records"""
        try:
            cutoff_date = datetime.now() - timedelta(days=days)
            
            # Delete old signals
            deleted_signals = self.db_manager.execute_query("""
                DELETE FROM signals 
                WHERE created_at < ? AND status IN ('CLOSED_PROFIT', 'CLOSED_LOSS', 'EXPIRED')
            """, (cutoff_date.isoformat(),))
            
            # Delete old analysis history
            deleted_analysis = self.db_manager.execute_query("""
                DELETE FROM analysis_history WHERE analyzed_at < ?
            """, (cutoff_date.isoformat(),))
            
            logger.info(f"🧹 Cleaned up old signals and analysis records")
            
        except Exception as e:
            logger.error(f"❌ Error cleaning up old signals: {e}")
