import psycopg2
import psycopg2.extras
import logging
import os
import threading
from typing import Dict, List, Optional, Any
from datetime import datetime
import json

logger = logging.getLogger(__name__)

class DatabaseManager:
    def __init__(self, db_path: str = None):
        self._lock = threading.Lock()
        self._connection = None
        
        # Use PostgreSQL connection from environment variables
        self.database_url = os.getenv('DATABASE_URL')
        if not self.database_url:
            raise ValueError("DATABASE_URL environment variable not set")
        
        # Initialize database
        self._initialize_database()
        
        logger.info("✅ PostgreSQL database initialized")

    def _initialize_database(self):
        """Initialize database with required tables"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                # Create tables
                self._create_tables(cursor)
                
                conn.commit()
                logger.info("✅ Database tables created successfully")
                
        except Exception as e:
            logger.error(f"❌ Error initializing database: {e}")
            raise

    def _create_tables(self, cursor):
        """Create all required database tables"""
        
        # Signals table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS signals (
                id SERIAL PRIMARY KEY,
                symbol VARCHAR(20) NOT NULL,
                timeframe VARCHAR(10) NOT NULL,
                signal_type VARCHAR(10) NOT NULL CHECK (signal_type IN ('BUY', 'SELL', 'HOLD')),
                entry_price DECIMAL(15,8) NOT NULL,
                stop_loss DECIMAL(15,8),
                take_profit DECIMAL(15,8),
                confidence DECIMAL(5,2) DEFAULT 0,
                strength DECIMAL(5,2) DEFAULT 0,
                risk_reward DECIMAL(10,2),
                position_size DECIMAL(15,8),
                patterns TEXT,
                volume_analysis TEXT,
                strategy_breakdown TEXT,
                ml_prediction TEXT,
                chart_path TEXT,
                status VARCHAR(20) DEFAULT 'OPEN' CHECK (status IN ('OPEN', 'CLOSED_PROFIT', 'CLOSED_LOSS', 'EXPIRED', 'CANCELLED')),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                closed_at TIMESTAMP,
                close_price DECIMAL(15,8),
                pnl_percent DECIMAL(10,2) DEFAULT 0,
                pnl_points DECIMAL(15,8) DEFAULT 0,
                close_reason TEXT,
                telegram_message_id BIGINT,
                notes TEXT
            )
        """)
        
        # Create indexes for signals table
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_signals_symbol_timeframe ON signals(symbol, timeframe)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_signals_status ON signals(status)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_signals_created_at ON signals(created_at)")
        
        # Analysis history table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS analysis_history (
                id SERIAL PRIMARY KEY,
                symbol VARCHAR(20) NOT NULL,
                timeframe VARCHAR(10) NOT NULL,
                analyzed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                signal_generated BOOLEAN DEFAULT FALSE,
                analysis_data TEXT,
                indicators_data TEXT,
                patterns_detected TEXT,
                volume_analysis TEXT,
                ml_prediction TEXT,
                processing_time_ms INTEGER,
                error_message TEXT
            )
        """)
        
        # Create indexes for analysis history
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_analysis_symbol_timeframe ON analysis_history(symbol, timeframe)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_analysis_analyzed_at ON analysis_history(analyzed_at)")
        
        # Performance summary table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS performance_summary (
                id SERIAL PRIMARY KEY,
                date DATE NOT NULL,
                symbol VARCHAR(20),
                timeframe VARCHAR(10),
                total_signals INTEGER DEFAULT 0,
                winning_signals INTEGER DEFAULT 0,
                losing_signals INTEGER DEFAULT 0,
                expired_signals INTEGER DEFAULT 0,
                total_pnl_percent DECIMAL(10,2) DEFAULT 0,
                total_pnl_points DECIMAL(15,8) DEFAULT 0,
                win_rate DECIMAL(5,2) DEFAULT 0,
                avg_win DECIMAL(10,2) DEFAULT 0,
                avg_loss DECIMAL(10,2) DEFAULT 0,
                profit_factor DECIMAL(10,2) DEFAULT 0,
                max_drawdown DECIMAL(10,2) DEFAULT 0,
                sharpe_ratio DECIMAL(10,4) DEFAULT 0,
                max_consecutive_wins INTEGER DEFAULT 0,
                max_consecutive_losses INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(date, symbol, timeframe)
            )
        """)
        
        # Strategy performance table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS strategy_performance (
                id SERIAL PRIMARY KEY,
                strategy_name VARCHAR(50) NOT NULL,
                date DATE NOT NULL,
                signals_count INTEGER DEFAULT 0,
                avg_score DECIMAL(5,2) DEFAULT 0,
                avg_confidence DECIMAL(5,2) DEFAULT 0,
                win_rate DECIMAL(5,2) DEFAULT 0,
                avg_pnl DECIMAL(10,2) DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(strategy_name, date)
            )
        """)
        
        # System logs table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS system_logs (
                id SERIAL PRIMARY KEY,
                log_level VARCHAR(20) NOT NULL,
                message TEXT NOT NULL,
                module VARCHAR(50),
                function_name VARCHAR(100),
                error_details TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Market data cache table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS market_data_cache (
                id SERIAL PRIMARY KEY,
                symbol VARCHAR(20) NOT NULL,
                timeframe VARCHAR(10) NOT NULL,
                data_json TEXT NOT NULL,
                cached_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at TIMESTAMP NOT NULL,
                UNIQUE(symbol, timeframe)
            )
        """)
        
        # Bot configuration table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS bot_config (
                id SERIAL PRIMARY KEY,
                config_key VARCHAR(100) NOT NULL UNIQUE,
                config_value TEXT NOT NULL,
                description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

    def _get_connection(self):
        """Get database connection with proper error handling"""
        try:
            if self._connection is None or self._connection.closed:
                self._connection = psycopg2.connect(
                    self.database_url,
                    cursor_factory=psycopg2.extras.RealDictCursor
                )
                self._connection.autocommit = False
                
            return self._connection
        except Exception as e:
            logger.error(f"❌ Database connection error: {e}")
            raise

    def execute_query(self, query: str, params: tuple = (), return_id: bool = False) -> Optional[int]:
        """Execute a query with proper error handling"""
        try:
            with self._lock:
                conn = self._get_connection()
                cursor = conn.cursor()
                cursor.execute(query, params)
                conn.commit()
                
                if return_id:
                    # PostgreSQL returns the ID differently
                    if 'RETURNING id' not in query.upper():
                        # Add RETURNING clause if not present
                        query = query.rstrip(';') + ' RETURNING id'
                        cursor.execute(query, params)
                        result = cursor.fetchone()
                        return result['id'] if result else None
                    else:
                        result = cursor.fetchone()
                        return result['id'] if result else None
                return cursor.rowcount
                
        except Exception as e:
            logger.error(f"❌ Database query error: {e}")
            logger.error(f"Query: {query}")
            logger.error(f"Params: {params}")
            raise

    def fetch_query(self, query: str, params: tuple = ()) -> Optional[List[Dict]]:
        """Fetch query results with proper error handling"""
        try:
            with self._lock:
                conn = self._get_connection()
                cursor = conn.cursor()
                cursor.execute(query, params)
                
                # Convert rows to dictionaries
                columns = [description[0] for description in cursor.description]
                rows = cursor.fetchall()
                
                if not rows:
                    return None
                
                return [dict(zip(columns, row)) for row in rows]
                
        except Exception as e:
            logger.error(f"❌ Database fetch error: {e}")
            logger.error(f"Query: {query}")
            logger.error(f"Params: {params}")
            return None

    def fetch_one(self, query: str, params: tuple = ()) -> Optional[Dict]:
        """Fetch single query result"""
        results = self.fetch_query(query, params)
        return results[0] if results else None

    def insert_signal(self, signal_data: Dict) -> Optional[int]:
        """Insert a new signal record"""
        try:
            query = """
                INSERT INTO signals (
                    symbol, timeframe, signal_type, entry_price, stop_loss, take_profit,
                    confidence, strength, risk_reward, position_size, patterns,
                    volume_analysis, strategy_breakdown, ml_prediction, chart_path
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING id
            """
            
            values = (
                signal_data.get('symbol'),
                signal_data.get('timeframe'),
                signal_data.get('signal_type'),
                signal_data.get('entry_price'),
                signal_data.get('stop_loss'),
                signal_data.get('take_profit'),
                signal_data.get('confidence'),
                signal_data.get('strength'),
                signal_data.get('risk_reward'),
                signal_data.get('position_size'),
                json.dumps(signal_data.get('patterns', [])),
                json.dumps(signal_data.get('volume_analysis', {})),
                json.dumps(signal_data.get('strategy_breakdown', {})),
                json.dumps(signal_data.get('ml_prediction', {})),
                signal_data.get('chart_path')
            )
            
            return self.execute_query(query, values, return_id=True)
            
        except Exception as e:
            logger.error(f"❌ Error inserting signal: {e}")
            return None

    def update_signal_status(self, signal_id: int, status_data: Dict) -> bool:
        """Update signal status and close information"""
        try:
            query = """
                UPDATE signals 
                SET status = ?, close_price = ?, pnl_percent = ?, pnl_points = ?, 
                    close_reason = ?, closed_at = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """
            
            values = (
                status_data.get('status'),
                status_data.get('close_price'),
                status_data.get('pnl_percent'),
                status_data.get('pnl_points'),
                status_data.get('close_reason'),
                status_data.get('closed_at', datetime.now().isoformat()),
                signal_id
            )
            
            rowcount = self.execute_query(query, values)
            return rowcount > 0
            
        except Exception as e:
            logger.error(f"❌ Error updating signal status: {e}")
            return False

    def get_open_signals(self) -> List[Dict]:
        """Get all open signals"""
        query = """
            SELECT * FROM signals 
            WHERE status = 'OPEN' 
            ORDER BY created_at DESC
        """
        return self.fetch_query(query) or []

    def get_signals_by_symbol(self, symbol: str, limit: int = 50) -> List[Dict]:
        """Get recent signals for a specific symbol"""
        query = """
            SELECT * FROM signals 
            WHERE symbol = ? 
            ORDER BY created_at DESC 
            LIMIT ?
        """
        return self.fetch_query(query, (symbol, limit)) or []

    def get_performance_stats(self, days: int = 30) -> Optional[Dict]:
        """Get performance statistics for the last N days"""
        try:
            cutoff_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            
            query = """
                SELECT 
                    COUNT(*) as total_signals,
                    SUM(CASE WHEN status = 'CLOSED_PROFIT' THEN 1 ELSE 0 END) as winning_signals,
                    SUM(CASE WHEN status = 'CLOSED_LOSS' THEN 1 ELSE 0 END) as losing_signals,
                    SUM(CASE WHEN status = 'EXPIRED' THEN 1 ELSE 0 END) as expired_signals,
                    AVG(CASE WHEN status IN ('CLOSED_PROFIT', 'CLOSED_LOSS') THEN pnl_percent END) as avg_pnl,
                    SUM(CASE WHEN status IN ('CLOSED_PROFIT', 'CLOSED_LOSS') THEN pnl_percent ELSE 0 END) as total_pnl,
                    MAX(pnl_percent) as best_trade,
                    MIN(pnl_percent) as worst_trade,
                    AVG(confidence) as avg_confidence,
                    AVG(strength) as avg_strength
                FROM signals 
                WHERE created_at >= datetime('now', '-{} days')
                AND status != 'OPEN'
            """.format(days)
            
            result = self.fetch_one(query)
            
            if result and result['total_signals'] > 0:
                # Calculate additional metrics
                win_rate = (result['winning_signals'] / result['total_signals']) * 100 if result['total_signals'] > 0 else 0
                
                return {
                    'total_signals': result['total_signals'],
                    'winning_signals': result['winning_signals'],
                    'losing_signals': result['losing_signals'],
                    'expired_signals': result['expired_signals'],
                    'win_rate': round(win_rate, 1),
                    'total_pnl': round(result['total_pnl'] or 0, 2),
                    'avg_pnl': round(result['avg_pnl'] or 0, 2),
                    'best_trade': round(result['best_trade'] or 0, 2),
                    'worst_trade': round(result['worst_trade'] or 0, 2),
                    'avg_confidence': round(result['avg_confidence'] or 0, 1),
                    'avg_strength': round(result['avg_strength'] or 0, 1)
                }
            
            return None
            
        except Exception as e:
            logger.error(f"❌ Error getting performance stats: {e}")
            return None

    def log_analysis(self, symbol: str, timeframe: str, analysis_data: Dict = None, 
                    signal_generated: bool = False, processing_time: int = None, 
                    error_message: str = None):
        """Log analysis attempt"""
        try:
            query = """
                INSERT INTO analysis_history (
                    symbol, timeframe, signal_generated, analysis_data, 
                    indicators_data, patterns_detected, volume_analysis, 
                    ml_prediction, processing_time_ms, error_message
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """
            
            values = (
                symbol,
                timeframe,
                signal_generated,
                json.dumps(analysis_data) if analysis_data else None,
                json.dumps(analysis_data.get('indicators', {})) if analysis_data else None,
                json.dumps(analysis_data.get('patterns', [])) if analysis_data else None,
                json.dumps(analysis_data.get('volume_analysis', {})) if analysis_data else None,
                json.dumps(analysis_data.get('ml_prediction', {})) if analysis_data else None,
                processing_time,
                error_message
            )
            
            self.execute_query(query, values)
            
        except Exception as e:
            logger.error(f"❌ Error logging analysis: {e}")

    def cache_market_data(self, symbol: str, timeframe: str, data: Dict, ttl_minutes: int = 5):
        """Cache market data"""
        try:
            expires_at = datetime.now()
            expires_at = expires_at.replace(minute=expires_at.minute + ttl_minutes)
            
            query = """
                INSERT OR REPLACE INTO market_data_cache (symbol, timeframe, data_json, expires_at)
                VALUES (?, ?, ?, ?)
            """
            
            values = (symbol, timeframe, json.dumps(data), expires_at.isoformat())
            self.execute_query(query, values)
            
        except Exception as e:
            logger.error(f"❌ Error caching market data: {e}")

    def get_cached_market_data(self, symbol: str, timeframe: str) -> Optional[Dict]:
        """Get cached market data if not expired"""
        try:
            query = """
                SELECT data_json FROM market_data_cache 
                WHERE symbol = ? AND timeframe = ? AND expires_at > CURRENT_TIMESTAMP
            """
            
            result = self.fetch_one(query, (symbol, timeframe))
            if result:
                return json.loads(result['data_json'])
            return None
            
        except Exception as e:
            logger.error(f"❌ Error getting cached data: {e}")
            return None

    def cleanup_old_data(self, days: int = 90):
        """Clean up old data"""
        try:
            cutoff_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            
            # Clean old closed signals
            query1 = "DELETE FROM signals WHERE status != 'OPEN' AND created_at < datetime('now', '-{} days')".format(days)
            deleted_signals = self.execute_query(query1)
            
            # Clean old analysis history
            query2 = "DELETE FROM analysis_history WHERE analyzed_at < datetime('now', '-{} days')".format(days)
            deleted_analysis = self.execute_query(query2)
            
            # Clean expired cache
            query3 = "DELETE FROM market_data_cache WHERE expires_at < CURRENT_TIMESTAMP"
            deleted_cache = self.execute_query(query3)
            
            # Clean old system logs
            query4 = "DELETE FROM system_logs WHERE created_at < datetime('now', '-{} days')".format(days)
            deleted_logs = self.execute_query(query4)
            
            logger.info(f"🧹 Cleanup completed: {deleted_signals} signals, {deleted_analysis} analysis, {deleted_cache} cache, {deleted_logs} logs")
            
        except Exception as e:
            logger.error(f"❌ Error during cleanup: {e}")

    def get_config(self, key: str, default_value: str = None) -> Optional[str]:
        """Get configuration value"""
        try:
            query = "SELECT config_value FROM bot_config WHERE config_key = ?"
            result = self.fetch_one(query, (key,))
            return result['config_value'] if result else default_value
        except:
            return default_value

    def set_config(self, key: str, value: str, description: str = None):
        """Set configuration value"""
        try:
            query = """
                INSERT OR REPLACE INTO bot_config (config_key, config_value, description, updated_at)
                VALUES (?, ?, ?, CURRENT_TIMESTAMP)
            """
            self.execute_query(query, (key, value, description))
        except Exception as e:
            logger.error(f"❌ Error setting config: {e}")

    def log_system_event(self, level: str, message: str, module: str = None, 
                        function_name: str = None, error_details: str = None):
        """Log system events"""
        try:
            query = """
                INSERT INTO system_logs (log_level, message, module, function_name, error_details)
                VALUES (?, ?, ?, ?, ?)
            """
            self.execute_query(query, (level, message, module, function_name, error_details))
        except Exception as e:
            logger.error(f"❌ Error logging system event: {e}")

    def vacuum_database(self):
        """Optimize database"""
        try:
            with self._lock:
                conn = self._get_connection()
                conn.execute("VACUUM")
                conn.execute("ANALYZE")
                logger.info("✅ Database optimized")
        except Exception as e:
            logger.error(f"❌ Error optimizing database: {e}")

    def get_database_stats(self) -> Dict:
        """Get database statistics"""
        try:
            stats = {}
            
            # Table counts
            tables = ['signals', 'analysis_history', 'performance_summary', 'strategy_performance', 'system_logs']
            for table in tables:
                query = f"SELECT COUNT(*) as count FROM {table}"
                result = self.fetch_one(query)
                stats[f"{table}_count"] = result['count'] if result else 0
            
            # Database size
            query = "SELECT page_count * page_size as size FROM pragma_page_count(), pragma_page_size()"
            result = self.fetch_one(query)
            stats['database_size_bytes'] = result['size'] if result else 0
            stats['database_size_mb'] = round(stats['database_size_bytes'] / (1024 * 1024), 2)
            
            return stats
            
        except Exception as e:
            logger.error(f"❌ Error getting database stats: {e}")
            return {}

    def close(self):
        """Close database connection"""
        try:
            if self._connection:
                self._connection.close()
                self._connection = None
                logger.info("✅ Database connection closed")
        except Exception as e:
            logger.error(f"❌ Error closing database: {e}")

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
