import pandas as pd
import numpy as np
import logging
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass

logger = logging.getLogger(__name__)

@dataclass
class StrategyResult:
    name: str
    score: float
    confidence: float
    signals: List[str]
    weight: float = 1.0

class TradingStrategies:
    def __init__(self, config: Dict):
        self.config = config
        self.strategy_weights = config.get('strategies', {})
        
        # Strategy configuration
        self.strategies = {
            'momentum': {
                'weight': self.strategy_weights.get('momentum', {}).get('weight', 1.0),
                'enabled': self.strategy_weights.get('momentum', {}).get('enabled', True)
            },
            'trend_following': {
                'weight': self.strategy_weights.get('trend_following', {}).get('weight', 1.2),
                'enabled': self.strategy_weights.get('trend_following', {}).get('enabled', True)
            },
            'mean_reversion': {
                'weight': self.strategy_weights.get('mean_reversion', {}).get('weight', 0.8),
                'enabled': self.strategy_weights.get('mean_reversion', {}).get('enabled', True)
            },
            'breakout': {
                'weight': self.strategy_weights.get('breakout', {}).get('weight', 1.1),
                'enabled': self.strategy_weights.get('breakout', {}).get('enabled', True)
            },
            'divergence': {
                'weight': self.strategy_weights.get('divergence', {}).get('weight', 0.9),
                'enabled': self.strategy_weights.get('divergence', {}).get('enabled', True)
            }
        }

    def momentum_strategy(self, row: pd.Series, patterns: List[str], 
                         volume_analysis: Dict) -> StrategyResult:
        """Momentum-based trading strategy"""
        try:
            score = 0
            confidence = 0
            signals = []
            
            # RSI momentum
            rsi = row.get('RSI', 50)
            if rsi < 25:
                score += 3
                confidence += 20
                signals.append('RSI oversold')
            elif rsi < 35:
                score += 2
                confidence += 15
                signals.append('RSI near oversold')
            elif rsi > 75:
                score -= 3
                confidence += 20
                signals.append('RSI overbought')
            elif rsi > 65:
                score -= 2
                confidence += 15
                signals.append('RSI near overbought')
            
            # MACD momentum
            macd = row.get('MACD', 0)
            macd_signal = row.get('MACD_Signal', 0)
            macd_hist = row.get('MACD_Histogram', 0)
            
            if macd > macd_signal and macd_hist > 0:
                score += 2
                confidence += 10
                signals.append('MACD bullish')
            elif macd < macd_signal and macd_hist < 0:
                score -= 2
                confidence += 10
                signals.append('MACD bearish')
            
            # Stochastic momentum
            stoch_k = row.get('Stoch_K', 50)
            stoch_d = row.get('Stoch_D', 50)
            
            if stoch_k < 20 and stoch_k > stoch_d:
                score += 1.5
                confidence += 8
                signals.append('Stochastic oversold crossover')
            elif stoch_k > 80 and stoch_k < stoch_d:
                score -= 1.5
                confidence += 8
                signals.append('Stochastic overbought crossover')
            
            # Williams %R
            williams_r = row.get('Williams_R', -50)
            if williams_r < -80:
                score += 1
                confidence += 5
                signals.append('Williams %R oversold')
            elif williams_r > -20:
                score -= 1
                confidence += 5
                signals.append('Williams %R overbought')
            
            # Volume confirmation
            if volume_analysis.get('volume_trend') == 'high':
                score *= 1.2
                confidence += 5
                signals.append('High volume confirmation')
            
            # Pattern confirmation
            bullish_patterns = ['hammer', 'bullish_engulfing', 'morning_star']
            bearish_patterns = ['shooting_star', 'bearish_engulfing', 'evening_star']
            
            if any(pattern in patterns for pattern in bullish_patterns):
                score += 1
                confidence += 8
                signals.append('Bullish pattern detected')
            elif any(pattern in patterns for pattern in bearish_patterns):
                score -= 1
                confidence += 8
                signals.append('Bearish pattern detected')
            
            return StrategyResult(
                name='momentum',
                score=round(score, 1),
                confidence=min(confidence, 100),
                signals=signals,
                weight=self.strategies['momentum']['weight']
            )
            
        except Exception as e:
            logger.error(f"❌ Error in momentum strategy: {e}")
            return StrategyResult('momentum', 0, 0, [], self.strategies['momentum']['weight'])

    def trend_following_strategy(self, row: pd.Series, patterns: List[str], 
                               volume_analysis: Dict) -> StrategyResult:
        """Trend following strategy"""
        try:
            score = 0
            confidence = 0
            signals = []
            
            # Moving average analysis
            close = row.get('Close', 0)
            sma_20 = row.get('SMA_20', close)
            sma_50 = row.get('SMA_50', close)
            sma_200 = row.get('SMA_200', close)
            ema_12 = row.get('EMA_12', close)
            ema_26 = row.get('EMA_26', close)
            
            # Short-term trend
            if close > sma_20 > sma_50:
                score += 2
                confidence += 15
                signals.append('Short-term uptrend')
            elif close < sma_20 < sma_50:
                score -= 2
                confidence += 15
                signals.append('Short-term downtrend')
            
            # Long-term trend
            if close > sma_200:
                score += 1.5
                confidence += 10
                signals.append('Above 200 SMA')
            elif close < sma_200:
                score -= 1.5
                confidence += 10
                signals.append('Below 200 SMA')
            
            # EMA crossover
            if ema_12 > ema_26:
                score += 1
                confidence += 8
                signals.append('EMA golden cross')
            elif ema_12 < ema_26:
                score -= 1
                confidence += 8
                signals.append('EMA death cross')
            
            # SuperTrend
            supertrend = row.get('SuperTrend', close)
            if close > supertrend:
                score += 2
                confidence += 12
                signals.append('SuperTrend bullish')
            elif close < supertrend:
                score -= 2
                confidence += 12
                signals.append('SuperTrend bearish')
            
            # Ichimoku analysis
            ichimoku_a = row.get('Ichimoku_A', close)
            ichimoku_b = row.get('Ichimoku_B', close)
            
            if close > ichimoku_a and close > ichimoku_b:
                score += 1.5
                confidence += 10
                signals.append('Above Ichimoku Cloud')
            elif close < ichimoku_a and close < ichimoku_b:
                score -= 1.5
                confidence += 10
                signals.append('Below Ichimoku Cloud')
            
            # Trend patterns
            trend_patterns = ['uptrend', 'downtrend']
            if 'uptrend' in patterns:
                score += 1
                confidence += 5
                signals.append('Chart uptrend')
            elif 'downtrend' in patterns:
                score -= 1
                confidence += 5
                signals.append('Chart downtrend')
            
            return StrategyResult(
                name='trend_following',
                score=round(score, 1),
                confidence=min(confidence, 100),
                signals=signals,
                weight=self.strategies['trend_following']['weight']
            )
            
        except Exception as e:
            logger.error(f"❌ Error in trend following strategy: {e}")
            return StrategyResult('trend_following', 0, 0, [], self.strategies['trend_following']['weight'])

    def mean_reversion_strategy(self, row: pd.Series, patterns: List[str], 
                              volume_analysis: Dict) -> StrategyResult:
        """Mean reversion strategy"""
        try:
            score = 0
            confidence = 0
            signals = []
            
            # Bollinger Bands mean reversion
            close = row.get('Close', 0)
            bb_upper = row.get('BB_Upper', close)
            bb_lower = row.get('BB_Lower', close)
            bb_middle = row.get('BB_Middle', close)
            bb_position = row.get('BB_Position', 0.5)
            
            if bb_position < 0.1:  # Near lower band
                score += 2.5
                confidence += 15
                signals.append('BB oversold')
            elif bb_position > 0.9:  # Near upper band
                score -= 2.5
                confidence += 15
                signals.append('BB overbought')
            elif 0.4 <= bb_position <= 0.6:  # Near middle
                score += 0.5
                confidence += 5
                signals.append('BB mean reversion zone')
            
            # RSI mean reversion (opposite to momentum)
            rsi = row.get('RSI', 50)
            if 25 <= rsi <= 35:
                score += 2
                confidence += 12
                signals.append('RSI mean reversion buy')
            elif 65 <= rsi <= 75:
                score -= 2
                confidence += 12
                signals.append('RSI mean reversion sell')
            
            # Stochastic mean reversion
            stoch_k = row.get('Stoch_K', 50)
            if 15 <= stoch_k <= 25:
                score += 1.5
                confidence += 8
                signals.append('Stochastic oversold reversion')
            elif 75 <= stoch_k <= 85:
                score -= 1.5
                confidence += 8
                signals.append('Stochastic overbought reversion')
            
            # CCI mean reversion
            cci = row.get('CCI', 0)
            if cci < -150:
                score += 1
                confidence += 6
                signals.append('CCI extreme oversold')
            elif cci > 150:
                score -= 1
                confidence += 6
                signals.append('CCI extreme overbought')
            
            # Pattern confirmation for mean reversion
            reversion_patterns = ['doji', 'hammer', 'shooting_star']
            if any(pattern in patterns for pattern in reversion_patterns):
                score += 0.5
                confidence += 5
                signals.append('Mean reversion pattern')
            
            return StrategyResult(
                name='mean_reversion',
                score=round(score, 1),
                confidence=min(confidence, 100),
                signals=signals,
                weight=self.strategies['mean_reversion']['weight']
            )
            
        except Exception as e:
            logger.error(f"❌ Error in mean reversion strategy: {e}")
            return StrategyResult('mean_reversion', 0, 0, [], self.strategies['mean_reversion']['weight'])

    def breakout_strategy(self, row: pd.Series, patterns: List[str], 
                        volume_analysis: Dict) -> StrategyResult:
        """Breakout trading strategy"""
        try:
            score = 0
            confidence = 0
            signals = []
            
            close = row.get('Close', 0)
            
            # Bollinger Band breakouts
            bb_upper = row.get('BB_Upper', close)
            bb_lower = row.get('BB_Lower', close)
            
            if close > bb_upper:
                score += 2.5
                confidence += 15
                signals.append('BB upper breakout')
            elif close < bb_lower:
                score -= 2.5
                confidence += 15
                signals.append('BB lower breakdown')
            
            # Keltner Channel breakouts
            kc_upper = row.get('KC_Upper', close)
            kc_lower = row.get('KC_Lower', close)
            
            if close > kc_upper:
                score += 2
                confidence += 12
                signals.append('KC upper breakout')
            elif close < kc_lower:
                score -= 2
                confidence += 12
                signals.append('KC lower breakdown')
            
            # Support/Resistance breakouts
            support = row.get('Support', close * 0.95)
            resistance = row.get('Resistance', close * 1.05)
            
            if close > resistance:
                score += 1.5
                confidence += 10
                signals.append('Resistance breakout')
            elif close < support:
                score -= 1.5
                confidence += 10
                signals.append('Support breakdown')
            
            # Volatility expansion
            atr = row.get('ATR', close * 0.02)
            bb_width = row.get('BB_Width', 2)
            
            if bb_width > 4:  # High volatility
                score *= 1.3
                confidence += 8
                signals.append('High volatility breakout')
            elif bb_width < 1:  # Low volatility squeeze
                score += 0.5
                confidence += 5
                signals.append('Volatility squeeze setup')
            
            # Volume confirmation (crucial for breakouts)
            volume_ratio = volume_analysis.get('volume_ratio', 1)
            if volume_ratio > 1.5:
                score *= 1.4
                confidence += 10
                signals.append('Volume breakout confirmation')
            elif volume_ratio < 0.8:
                score *= 0.7
                confidence -= 5
                signals.append('Weak volume on breakout')
            
            # Pattern-based breakouts
            breakout_patterns = ['breakout_up', 'breakout_down', 'triangle_symmetrical']
            if 'breakout_up' in patterns:
                score += 1.5
                confidence += 8
                signals.append('Bullish breakout pattern')
            elif 'breakout_down' in patterns:
                score -= 1.5
                confidence += 8
                signals.append('Bearish breakdown pattern')
            
            return StrategyResult(
                name='breakout',
                score=round(score, 1),
                confidence=min(confidence, 100),
                signals=signals,
                weight=self.strategies['breakout']['weight']
            )
            
        except Exception as e:
            logger.error(f"❌ Error in breakout strategy: {e}")
            return StrategyResult('breakout', 0, 0, [], self.strategies['breakout']['weight'])

    def divergence_strategy(self, row: pd.Series, patterns: List[str], 
                          volume_analysis: Dict, ml_prediction: Optional[Dict] = None) -> StrategyResult:
        """Divergence detection strategy"""
        try:
            score = 0
            confidence = 0
            signals = []
            
            # Note: This is a simplified divergence detection
            # In practice, you'd need price history to detect proper divergences
            
            # Volume-Price divergence
            if volume_analysis.get('divergence', False):
                score += 1.5
                confidence += 10
                signals.append('Price-Volume divergence')
            
            # MACD potential divergence signals
            macd_hist = row.get('MACD_Histogram', 0)
            if abs(macd_hist) < 0.001:  # MACD histogram near zero
                score += 0.5
                confidence += 5
                signals.append('MACD potential divergence zone')
            
            # RSI divergence potential
            rsi = row.get('RSI', 50)
            if 40 <= rsi <= 60:  # RSI in middle zone might indicate divergence setup
                score += 0.3
                confidence += 3
                signals.append('RSI divergence potential')
            
            # OBV trend vs price (simplified)
            obv_trend = volume_analysis.get('obv_trend', 'neutral')
            close = row.get('Close', 0)
            sma_20 = row.get('SMA_20', close)
            
            if obv_trend == 'bullish' and close < sma_20:
                score += 1
                confidence += 8
                signals.append('OBV-Price bullish divergence potential')
            elif obv_trend == 'bearish' and close > sma_20:
                score -= 1
                confidence += 8
                signals.append('OBV-Price bearish divergence potential')
            
            # ML prediction divergence
            if ml_prediction:
                ml_direction = ml_prediction.get('direction', 'neutral')
                current_trend = 'bullish' if close > sma_20 else 'bearish'
                
                if ml_direction != current_trend and ml_prediction.get('confidence', 0) > 70:
                    if ml_direction == 'bullish':
                        score += 1.5
                    else:
                        score -= 1.5
                    confidence += 12
                    signals.append(f'ML-Price divergence: {ml_direction}')
            
            # Momentum divergence patterns
            momentum_patterns = ['doji', 'hammer', 'shooting_star']
            if any(pattern in patterns for pattern in momentum_patterns):
                score += 0.5
                confidence += 5
                signals.append('Momentum divergence pattern')
            
            return StrategyResult(
                name='divergence',
                score=round(score, 1),
                confidence=min(confidence, 100),
                signals=signals,
                weight=self.strategies['divergence']['weight']
            )
            
        except Exception as e:
            logger.error(f"❌ Error in divergence strategy: {e}")
            return StrategyResult('divergence', 0, 0, [], self.strategies['divergence']['weight'])

    def get_all_signals(self, row: pd.Series, patterns: List[str], 
                       volume_analysis: Dict, ml_prediction: Optional[Dict] = None) -> Dict[str, StrategyResult]:
        """Get signals from all enabled strategies"""
        try:
            strategy_results = {}
            
            if self.strategies['momentum']['enabled']:
                strategy_results['momentum'] = self.momentum_strategy(row, patterns, volume_analysis)
            
            if self.strategies['trend_following']['enabled']:
                strategy_results['trend_following'] = self.trend_following_strategy(row, patterns, volume_analysis)
            
            if self.strategies['mean_reversion']['enabled']:
                strategy_results['mean_reversion'] = self.mean_reversion_strategy(row, patterns, volume_analysis)
            
            if self.strategies['breakout']['enabled']:
                strategy_results['breakout'] = self.breakout_strategy(row, patterns, volume_analysis)
            
            if self.strategies['divergence']['enabled']:
                strategy_results['divergence'] = self.divergence_strategy(row, patterns, volume_analysis, ml_prediction)
            
            return strategy_results
            
        except Exception as e:
            logger.error(f"❌ Error getting all strategy signals: {e}")
            return {}

    def combine_signals(self, strategy_results: Dict[str, StrategyResult]) -> Dict:
        """Combine multiple strategy signals into final signal"""
        try:
            if not strategy_results:
                return {'type': 'HOLD', 'strength': 0, 'confidence': 0}
            
            total_weighted_score = 0
            total_weight = 0
            total_confidence = 0
            all_signals = []
            
            # Calculate weighted average
            for strategy_name, result in strategy_results.items():
                weighted_score = result.score * result.weight
                total_weighted_score += weighted_score
                total_weight += result.weight
                total_confidence += result.confidence
                all_signals.extend(result.signals)
            
            # Calculate final metrics
            if total_weight == 0:
                return {'type': 'HOLD', 'strength': 0, 'confidence': 0}
            
            final_score = total_weighted_score / total_weight
            avg_confidence = total_confidence / len(strategy_results)
            
            # Determine signal type based on score and confidence thresholds
            min_confidence = self.config.get('min_confidence', 60)
            min_strength = self.config.get('min_strength', 1.5)
            
            if avg_confidence < min_confidence:
                signal_type = 'HOLD'
            elif final_score >= min_strength:
                signal_type = 'BUY'
            elif final_score <= -min_strength:
                signal_type = 'SELL'
            else:
                signal_type = 'HOLD'
            
            # Apply additional filters
            signal_strength = abs(final_score)
            
            # Reduce strength if conflicting signals
            bullish_count = sum(1 for result in strategy_results.values() if result.score > 0)
            bearish_count = sum(1 for result in strategy_results.values() if result.score < 0)
            
            if bullish_count > 0 and bearish_count > 0:
                # Conflicting signals - reduce confidence
                avg_confidence *= 0.8
                signal_strength *= 0.9
            
            return {
                'type': signal_type,
                'strength': round(signal_strength, 1),
                'confidence': round(avg_confidence, 1),
                'final_score': round(final_score, 2),
                'strategy_breakdown': {name: {
                    'score': result.score,
                    'confidence': result.confidence,
                    'signals': result.signals,
                    'weight': result.weight
                } for name, result in strategy_results.items()},
                'combined_signals': all_signals
            }
            
        except Exception as e:
            logger.error(f"❌ Error combining signals: {e}")
            return {'type': 'HOLD', 'strength': 0, 'confidence': 0}

    def validate_signal(self, signal: Dict, current_data: pd.Series) -> bool:
        """Validate signal before sending"""
        try:
            # Basic validation
            if signal['type'] == 'HOLD':
                return False
            
            # Minimum confidence check
            if signal['confidence'] < self.config.get('min_confidence', 60):
                return False
            
            # Minimum strength check
            if signal['strength'] < self.config.get('min_strength', 1.5):
                return False
            
            # Market condition checks
            close = current_data.get('Close', 0)
            volume = current_data.get('Volume', 0)
            
            # Don't trade on very low volume
            volume_sma = current_data.get('Volume_SMA', volume)
            if volume < volume_sma * 0.3:
                logger.info("⚠️ Signal rejected: Very low volume")
                return False
            
            # Don't trade during extreme volatility
            atr = current_data.get('ATR', close * 0.02)
            if atr > close * 0.1:  # More than 10% ATR
                logger.info("⚠️ Signal rejected: Extreme volatility")
                return False
            
            return True
            
        except Exception as e:
            logger.error(f"❌ Error validating signal: {e}")
            return False
